"""
Pharmacy Entry Flow Lambda
Handles Amazon Connect call flow logic and routes to appropriate services
"""

import json
import boto3
import logging
from typing import Dict, Any

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
lex_client = boto3.client('lexv2-runtime')
connect_client = boto3.client('connect')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main handler for Pharmacy Entry Flow Lambda
    
    Args:
        event: Amazon Connect event data
        context: Lambda context
        
    Returns:
        Response for Amazon Connect
    """
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Extract call details
        contact_id = event.get('Details', {}).get('ContactData', {}).get('ContactId')
        customer_number = event.get('Details', {}).get('ContactData', {}).get('CustomerEndpoint', {}).get('Address')
        
        # Determine call routing based on customer input
        customer_input = event.get('Details', {}).get('Parameters', {}).get('CustomerInput', '').lower()
        
        if 'prescription' in customer_input or 'medication' in customer_input:
            # Route to prescription services
            response = route_to_prescription_service(contact_id, customer_number, customer_input)
        elif 'refill' in customer_input:
            # Route to refill services
            response = route_to_refill_service(contact_id, customer_number, customer_input)
        elif 'pharmacy' in customer_input or 'store' in customer_input:
            # Route to general pharmacy services
            response = route_to_pharmacy_service(contact_id, customer_number, customer_input)
        else:
            # Default routing to main menu
            response = route_to_main_menu(contact_id, customer_number)
            
        logger.info(f"Routing response: {json.dumps(response)}")
        return response
        
    except Exception as e:
        logger.error(f"Error in pharmacy entry flow: {str(e)}")
        return create_error_response()

def route_to_prescription_service(contact_id: str, customer_number: str, input_text: str) -> Dict[str, Any]:
    """Route customer to prescription services via Lex bot"""
    try:
        # Initialize session with Lex bot
        lex_response = lex_client.recognize_text(
            botId='ABC_PHARMACY_BOT',
            botAliasId='TSTALIASID',
            localeId='en_US',
            sessionId=contact_id,
            text=input_text
        )
        
        return {
            'statusCode': 200,
            'body': {
                'action': 'transfer_to_lex',
                'bot_response': lex_response.get('messages', []),
                'session_attributes': {
                    'customer_number': customer_number,
                    'service_type': 'prescription',
                    'contact_id': contact_id
                }
            }
        }
    except Exception as e:
        logger.error(f"Error routing to prescription service: {str(e)}")
        return create_error_response()

def route_to_refill_service(contact_id: str, customer_number: str, input_text: str) -> Dict[str, Any]:
    """Route customer to prescription refill services"""
    return {
        'statusCode': 200,
        'body': {
            'action': 'transfer_to_lex',
            'message': 'Connecting you to our prescription refill service...',
            'session_attributes': {
                'customer_number': customer_number,
                'service_type': 'refill',
                'contact_id': contact_id,
                'intent': 'RefillPrescription'
            }
        }
    }

def route_to_pharmacy_service(contact_id: str, customer_number: str, input_text: str) -> Dict[str, Any]:
    """Route customer to general pharmacy services"""
    return {
        'statusCode': 200,
        'body': {
            'action': 'transfer_to_lex',
            'message': 'Connecting you to our pharmacy services...',
            'session_attributes': {
                'customer_number': customer_number,
                'service_type': 'general',
                'contact_id': contact_id,
                'intent': 'GeneralInquiry'
            }
        }
    }

def route_to_main_menu(contact_id: str, customer_number: str) -> Dict[str, Any]:
    """Route customer to main menu"""
    return {
        'statusCode': 200,
        'body': {
            'action': 'play_prompt',
            'message': 'Welcome to ABC Pharmacy. Say "prescription" for prescription services, "refill" for refills, or "pharmacy" for general inquiries.',
            'session_attributes': {
                'customer_number': customer_number,
                'service_type': 'main_menu',
                'contact_id': contact_id
            }
        }
    }

def create_error_response() -> Dict[str, Any]:
    """Create error response for Connect"""
    return {
        'statusCode': 500,
        'body': {
            'action': 'play_prompt',
            'message': 'I apologize, but we are experiencing technical difficulties. Please try again later or speak with a representative.',
            'transfer_to_agent': True
        }
    }