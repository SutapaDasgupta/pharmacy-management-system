"""
MCP Server Validate Prescription Lambda
Model Context Protocol server for prescription validation services
"""

import json
import boto3
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import re

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')

# DynamoDB tables
prescriptions_table = dynamodb.Table('prescriptions')
medications_table = dynamodb.Table('medications')
doctors_table = dynamodb.Table('doctors')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main handler for MCP Server Validate Prescription Lambda
    
    Args:
        event: MCP request event
        context: Lambda context
        
    Returns:
        MCP response
    """
    try:
        logger.info(f"Received MCP request: {json.dumps(event)}")
        
        method = event.get('method')
        params = event.get('params', {})
        
        if method == 'validate_prescription':
            return validate_prescription(params)
        elif method == 'check_drug_interactions':
            return check_drug_interactions(params)
        elif method == 'verify_insurance':
            return verify_insurance(params)
        elif method == 'check_dosage':
            return check_dosage(params)
        elif method == 'verify_doctor':
            return verify_doctor(params)
        else:
            return create_mcp_error_response(f"Unknown method: {method}")
            
    except Exception as e:
        logger.error(f"Error in MCP Server: {str(e)}")
        return create_mcp_error_response(str(e))

def validate_prescription(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate prescription data and requirements
    
    Args:
        params: Prescription validation parameters
        
    Returns:
        Validation response
    """
    try:
        prescription = params.get('prescription', {})
        
        validation_results = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'details': {}
        }
        
        # Validate required fields
        required_fields = ['patient_name', 'medication_name', 'doctor_name', 'prescription_number']
        for field in required_fields:
            if not prescription.get(field):
                validation_results['errors'].append(f"Missing required field: {field}")
                validation_results['valid'] = False
        
        # Validate prescription number format
        prescription_number = prescription.get('prescription_number', '')
        if prescription_number and not re.match(r'^[A-Z0-9]{8,12}$', prescription_number):
            validation_results['errors'].append("Invalid prescription number format")
            validation_results['valid'] = False
        
        # Validate medication
        medication_validation = validate_medication(prescription.get('medication_name', ''))
        if not medication_validation['valid']:
            validation_results['errors'].extend(medication_validation['errors'])
            validation_results['valid'] = False
        else:
            validation_results['details']['medication'] = medication_validation['details']
        
        # Validate doctor
        doctor_validation = validate_doctor_info(prescription.get('doctor_name', ''))
        if not doctor_validation['valid']:
            validation_results['warnings'].extend(doctor_validation['warnings'])
        else:
            validation_results['details']['doctor'] = doctor_validation['details']
        
        # Validate dosage if provided
        if prescription.get('dosage'):
            dosage_validation = validate_dosage(
                prescription.get('medication_name', ''),
                prescription.get('dosage', '')
            )
            if not dosage_validation['valid']:
                validation_results['warnings'].extend(dosage_validation['warnings'])
            else:
                validation_results['details']['dosage'] = dosage_validation['details']
        
        # Check for duplicate prescriptions
        duplicate_check = check_duplicate_prescription(prescription)
        if duplicate_check['found']:
            validation_results['warnings'].append("Similar prescription found in recent history")
            validation_results['details']['duplicate_info'] = duplicate_check['details']
        
        return {
            'statusCode': 200,
            'body': json.dumps(validation_results)
        }
        
    except Exception as e:
        logger.error(f"Error validating prescription: {str(e)}")
        return create_mcp_error_response(f"Prescription validation error: {str(e)}")

def validate_medication(medication_name: str) -> Dict[str, Any]:
    """
    Validate medication name and details
    
    Args:
        medication_name: Name of the medication
        
    Returns:
        Medication validation result
    """
    try:
        # Mock medication database lookup
        # In real implementation, this would query a medication database
        known_medications = {
            'amoxicillin': {
                'generic_name': 'amoxicillin',
                'brand_names': ['Amoxil', 'Trimox'],
                'drug_class': 'antibiotic',
                'controlled': False,
                'common_dosages': ['250mg', '500mg', '875mg']
            },
            'lisinopril': {
                'generic_name': 'lisinopril',
                'brand_names': ['Prinivil', 'Zestril'],
                'drug_class': 'ACE inhibitor',
                'controlled': False,
                'common_dosages': ['5mg', '10mg', '20mg', '40mg']
            },
            'oxycodone': {
                'generic_name': 'oxycodone',
                'brand_names': ['OxyContin', 'Percocet'],
                'drug_class': 'opioid',
                'controlled': True,
                'schedule': 'II',
                'common_dosages': ['5mg', '10mg', '15mg', '20mg', '30mg']
            }
        }
        
        medication_lower = medication_name.lower()
        
        # Check if medication exists
        medication_info = known_medications.get(medication_lower)
        
        if medication_info:
            return {
                'valid': True,
                'details': medication_info,
                'errors': []
            }
        else:
            # Check if it might be a brand name
            for generic, info in known_medications.items():
                if medication_lower in [brand.lower() for brand in info['brand_names']]:
                    return {
                        'valid': True,
                        'details': info,
                        'errors': []
                    }
            
            return {
                'valid': False,
                'details': {},
                'errors': [f"Unknown medication: {medication_name}"]
            }
            
    except Exception as e:
        logger.error(f"Error validating medication: {str(e)}")
        return {
            'valid': False,
            'details': {},
            'errors': [f"Medication validation error: {str(e)}"]
        }

def validate_doctor_info(doctor_name: str) -> Dict[str, Any]:
    """
    Validate doctor information
    
    Args:
        doctor_name: Name of the prescribing doctor
        
    Returns:
        Doctor validation result
    """
    try:
        # Mock doctor database lookup
        known_doctors = {
            'dr. smith': {
                'full_name': 'Dr. John Smith',
                'license_number': 'MD123456',
                'specialties': ['Family Medicine'],
                'verified': True
            },
            'dr. johnson': {
                'full_name': 'Dr. Sarah Johnson',
                'license_number': 'MD789012',
                'specialties': ['Internal Medicine'],
                'verified': True
            }
        }
        
        doctor_lower = doctor_name.lower()
        doctor_info = known_doctors.get(doctor_lower)
        
        if doctor_info:
            return {
                'valid': True,
                'details': doctor_info,
                'warnings': []
            }
        else:
            return {
                'valid': False,
                'details': {},
                'warnings': [f"Doctor not found in verified database: {doctor_name}"]
            }
            
    except Exception as e:
        logger.error(f"Error validating doctor: {str(e)}")
        return {
            'valid': False,
            'details': {},
            'warnings': [f"Doctor validation error: {str(e)}"]
        }

def validate_dosage(medication_name: str, dosage: str) -> Dict[str, Any]:
    """
    Validate medication dosage
    
    Args:
        medication_name: Name of the medication
        dosage: Prescribed dosage
        
    Returns:
        Dosage validation result
    """
    try:
        # This would typically check against medication-specific dosage ranges
        dosage_pattern = re.match(r'^(\d+(?:\.\d+)?)\s*(mg|g|ml|units?)(?:\s*(?:per|/)\s*day)?$', dosage.lower())
        
        if not dosage_pattern:
            return {
                'valid': False,
                'details': {},
                'warnings': [f"Invalid dosage format: {dosage}"]
            }
        
        amount = float(dosage_pattern.group(1))
        unit = dosage_pattern.group(2)
        
        # Basic dosage validation (would be more sophisticated in real implementation)
        if unit == 'mg' and amount > 10000:  # Very high dose
            return {
                'valid': False,
                'details': {},
                'warnings': [f"Unusually high dosage: {dosage}"]
            }
        
        return {
            'valid': True,
            'details': {
                'amount': amount,
                'unit': unit,
                'parsed_dosage': dosage
            },
            'warnings': []
        }
        
    except Exception as e:
        logger.error(f"Error validating dosage: {str(e)}")
        return {
            'valid': False,
            'details': {},
            'warnings': [f"Dosage validation error: {str(e)}"]
        }

def check_duplicate_prescription(prescription: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check for duplicate prescriptions
    
    Args:
        prescription: Prescription data
        
    Returns:
        Duplicate check result
    """
    try:
        # Mock duplicate check (would query prescription history in real implementation)
        # For demo purposes, assume no duplicates found
        return {
            'found': False,
            'details': {}
        }
        
    except Exception as e:
        logger.error(f"Error checking duplicates: {str(e)}")
        return {
            'found': False,
            'details': {'error': str(e)}
        }

def check_drug_interactions(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check for drug interactions
    
    Args:
        params: Drug interaction check parameters
        
    Returns:
        Drug interaction response
    """
    try:
        medication = params.get('medication', '')
        current_medications = params.get('patient_medications', [])
        allergies = params.get('patient_allergies', [])
        
        # Mock drug interaction database
        interactions = {
            'warfarin': ['aspirin', 'ibuprofen'],
            'lisinopril': ['potassium supplements'],
            'metformin': ['alcohol']
        }
        
        found_interactions = []
        medication_lower = medication.lower()
        
        # Check interactions with current medications
        for current_med in current_medications:
            current_med_lower = current_med.lower()
            if (medication_lower in interactions.get(current_med_lower, []) or
                current_med_lower in interactions.get(medication_lower, [])):
                found_interactions.append({
                    'medication1': medication,
                    'medication2': current_med,
                    'severity': 'moderate',
                    'description': f"Potential interaction between {medication} and {current_med}"
                })
        
        # Check allergies
        allergy_warnings = []
        for allergy in allergies:
            if allergy.lower() in medication_lower:
                allergy_warnings.append({
                    'allergy': allergy,
                    'medication': medication,
                    'severity': 'high',
                    'description': f"Patient is allergic to {allergy}"
                })
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'interactions_found': len(found_interactions) > 0 or len(allergy_warnings) > 0,
                'interactions': found_interactions,
                'allergy_warnings': allergy_warnings,
                'severity_levels': [interaction['severity'] for interaction in found_interactions + allergy_warnings],
                'recommendations': [
                    "Consult with pharmacist before dispensing" if found_interactions or allergy_warnings else "No interactions found"
                ]
            })
        }
        
    except Exception as e:
        logger.error(f"Error checking drug interactions: {str(e)}")
        return create_mcp_error_response(f"Drug interaction check error: {str(e)}")

def verify_insurance(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Verify insurance coverage
    
    Args:
        params: Insurance verification parameters
        
    Returns:
        Insurance verification response
    """
    try:
        medication = params.get('medication', '')
        insurance_info = params.get('insurance_info', {})
        
        # Mock insurance verification
        # In real implementation, this would integrate with insurance APIs
        
        coverage_info = {
            'covered': True,
            'copay': 10.00,
            'coverage_details': {
                'tier': 'generic',
                'coverage_percentage': 80,
                'deductible_applied': False
            },
            'prior_auth_required': False
        }
        
        # Simulate some medications requiring prior authorization
        if 'oxycodone' in medication.lower():
            coverage_info['prior_auth_required'] = True
            coverage_info['copay'] = 25.00
        
        return {
            'statusCode': 200,
            'body': json.dumps(coverage_info)
        }
        
    except Exception as e:
        logger.error(f"Error verifying insurance: {str(e)}")
        return create_mcp_error_response(f"Insurance verification error: {str(e)}")

def check_dosage(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check dosage appropriateness
    
    Args:
        params: Dosage check parameters
        
    Returns:
        Dosage check response
    """
    try:
        medication = params.get('medication', '')
        dosage = params.get('dosage', '')
        patient_info = params.get('patient_info', {})
        
        dosage_result = validate_dosage(medication, dosage)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'dosage_appropriate': dosage_result['valid'],
                'warnings': dosage_result.get('warnings', []),
                'recommendations': [
                    "Dosage within normal range" if dosage_result['valid'] else "Review dosage with prescriber"
                ]
            })
        }
        
    except Exception as e:
        logger.error(f"Error checking dosage: {str(e)}")
        return create_mcp_error_response(f"Dosage check error: {str(e)}")

def verify_doctor(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Verify doctor credentials
    
    Args:
        params: Doctor verification parameters
        
    Returns:
        Doctor verification response
    """
    try:
        doctor_name = params.get('doctor_name', '')
        
        doctor_result = validate_doctor_info(doctor_name)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'doctor_verified': doctor_result['valid'],
                'doctor_details': doctor_result.get('details', {}),
                'warnings': doctor_result.get('warnings', [])
            })
        }
        
    except Exception as e:
        logger.error(f"Error verifying doctor: {str(e)}")
        return create_mcp_error_response(f"Doctor verification error: {str(e)}")

def create_mcp_error_response(error_message: str) -> Dict[str, Any]:
    """
    Create MCP error response
    
    Args:
        error_message: Error description
        
    Returns:
        MCP error response
    """
    return {
        'statusCode': 500,
        'body': json.dumps({
            'error': {
                'code': -32603,
                'message': 'Internal error',
                'data': error_message
            }
        })
    }