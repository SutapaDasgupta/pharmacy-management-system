"""
MCP Client Lambda Handler
Interfaces with MCP Server for prescription validation
"""

import json
import boto3
import logging
import requests
import os
from typing import Dict, Any

logger = logging.getLogger()
logger.setLevel(logging.INFO)

lambda_client = boto3.client('lambda')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Handle MCP client requests for prescription validation
    """
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        action = event.get('action', '')
        prescription_number = event.get('prescriptionNumber', '')
        patient_name = event.get('patientName', '')
        request_id = event.get('requestId', '')
        
        if not all([action, prescription_number, patient_name]):
            raise ValueError("Missing required parameters: action, prescriptionNumber, patientName")
        
        if action == 'validate':
            result = validate_prescription(prescription_number, patient_name, request_id)
        else:
            raise ValueError(f"Unsupported action: {action}")
        
        return {
            'statusCode': 200,
            'isValid': result['isValid'],
            'validationDetails': result['details'],
            'requestId': request_id
        }
        
    except Exception as e:
        logger.error(f"Error in MCP client: {str(e)}")
        return {
            'statusCode': 500,
            'isValid': False,
            'error': str(e),
            'requestId': request_id
        }

def validate_prescription(prescription_number: str, patient_name: str, request_id: str) -> Dict[str, Any]:
    """
    Validate prescription using MCP Server
    """
    try:
        # Call MCP Server Lambda for validation
        mcp_server_function = os.environ.get('MCP_SERVER_FUNCTION_NAME', 'mcp-server-validate-prescription-lambda')
        
        payload = {
            'method': 'validate_prescription',
            'params': {
                'prescription_number': prescription_number,
                'patient_name': patient_name,
                'request_id': request_id
            }
        }
        
        response = lambda_client.invoke(
            FunctionName=mcp_server_function,
            InvocationType='RequestResponse',
            Payload=json.dumps(payload)
        )
        
        response_payload = json.loads(response['Payload'].read())
        
        if response_payload.get('statusCode') == 200:
            return {
                'isValid': response_payload.get('isValid', False),
                'details': response_payload.get('validationDetails', {})
            }
        else:
            logger.error(f"MCP Server returned error: {response_payload}")
            return {
                'isValid': False,
                'details': {'error': 'MCP Server validation failed'}
            }
            
    except Exception as e:
        logger.error(f"Error calling MCP Server: {str(e)}")
        return {
            'isValid': False,
            'details': {'error': f'MCP Server call failed: {str(e)}'}
        }