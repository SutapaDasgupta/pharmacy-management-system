"""
Prescription Processor Lambda Handler
Core prescription processing logic and data management
"""

import json
import boto3
import logging
import uuid
from typing import Dict, Any
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
sns_client = boto3.client('sns')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Handle prescription processing requests
    """
    try:
        logger.info(f"Received processing request: {json.dumps(event)}")
        
        prescription_number = event.get('prescriptionNumber', '')
        patient_name = event.get('patientName', '')
        validation_data = event.get('validationData', {})
        request_id = event.get('requestId', '')
        
        if not all([prescription_number, patient_name, validation_data]):
            raise ValueError("Missing required parameters")
        
        # Process the prescription
        processing_result = process_prescription_refill(
            prescription_number, 
            patient_name, 
            validation_data, 
            request_id
        )
        
        return {
            'statusCode': 200,
            'status': 'SUCCESS',
            'processingResult': processing_result,
            'requestId': request_id
        }
        
    except Exception as e:
        logger.error(f"Error processing prescription: {str(e)}")
        return {
            'statusCode': 500,
            'status': 'FAILED',
            'error': str(e),
            'requestId': event.get('requestId', '')
        }

def process_prescription_refill(prescription_number: str, patient_name: str, 
                              validation_data: Dict[str, Any], request_id: str) -> Dict[str, Any]:
    """
    Process prescription refill request
    """
    try:
        # Generate processing ID
        processing_id = str(uuid.uuid4())
        
        # Extract prescription data from validation
        prescription_data = validation_data.get('prescription_data', {})
        
        # Create refill record
        refill_record = {
            'processing_id': processing_id,
            'prescription_number': prescription_number,
            'patient_name': patient_name,
            'medication': prescription_data.get('medication', ''),
            'prescriber': prescription_data.get('prescriber', ''),
            'refill_date': datetime.now().isoformat(),
            'status': 'processing',
            'request_id': request_id,
            'validation_data': validation_data
        }
        
        # Save to database
        save_refill_record(refill_record)
        
        # Update prescription refill count
        update_prescription_refills(prescription_number)
        
        # Notify pharmacy staff
        notify_pharmacy_staff(refill_record)
        
        # Simulate processing time and update status
        refill_record['status'] = 'ready_for_pickup'
        refill_record['ready_time'] = datetime.now().isoformat()
        
        # Update record with final status
        save_refill_record(refill_record)
        
        return {
            'processing_id': processing_id,
            'status': 'ready_for_pickup',
            'medication': prescription_data.get('medication', ''),
            'ready_time': refill_record['ready_time'],
            'pickup_instructions': 'Please bring valid ID when picking up your prescription',
            'pharmacy_location': 'ABC Pharmacy - Main Street Location'
        }
        
    except Exception as e:
        logger.error(f"Error in prescription processing: {str(e)}")
        raise

def save_refill_record(refill_record: Dict[str, Any]) -> None:
    """
    Save refill record to DynamoDB
    """
    try:
        # In a real implementation, this would save to DynamoDB
        # For now, we'll just log the record
        logger.info(f"Saving refill record: {json.dumps(refill_record, default=str)}")
        
        # Example DynamoDB save (commented out for demo):
        # table = dynamodb.Table('prescription_refills')
        # table.put_item(Item=refill_record)
        
    except Exception as e:
        logger.error(f"Error saving refill record: {str(e)}")
        raise

def update_prescription_refills(prescription_number: str) -> None:
    """
    Update prescription refill count
    """
    try:
        # In a real implementation, this would update the prescription record
        logger.info(f"Updating refill count for prescription: {prescription_number}")
        
        # Example DynamoDB update (commented out for demo):
        # table = dynamodb.Table('prescriptions')
        # table.update_item(
        #     Key={'prescription_number': prescription_number},
        #     UpdateExpression='SET refills_remaining = refills_remaining - :val',
        #     ExpressionAttributeValues={':val': 1}
        # )
        
    except Exception as e:
        logger.error(f"Error updating prescription refills: {str(e)}")
        raise

def notify_pharmacy_staff(refill_record: Dict[str, Any]) -> None:
    """
    Notify pharmacy staff about new refill request
    """
    try:
        message = {
            'type': 'new_refill_request',
            'processing_id': refill_record['processing_id'],
            'prescription_number': refill_record['prescription_number'],
            'patient_name': refill_record['patient_name'],
            'medication': refill_record['medication'],
            'timestamp': refill_record['refill_date']
        }
        
        logger.info(f"Notifying pharmacy staff: {json.dumps(message)}")
        
        # Example SNS notification (commented out for demo):
        # sns_client.publish(
        #     TopicArn='arn:aws:sns:region:account:pharmacy-staff-notifications',
        #     Message=json.dumps(message),
        #     Subject=f'New Refill Request - {refill_record["prescription_number"]}'
        # )
        
    except Exception as e:
        logger.error(f"Error notifying pharmacy staff: {str(e)}")
        # Don't raise here as this is not critical for the main flow