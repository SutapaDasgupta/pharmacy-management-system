"""
Pharmacy Entry Flow Lambda Handler
Handles Amazon Connect call flow logic and routes to ABCPharmacyBot
"""

import json
import boto3
import logging
from typing import Dict, Any

logger = logging.getLogger()
logger.setLevel(logging.INFO)

lex_client = boto3.client('lexv2-runtime')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Handle incoming Connect call flow events
    """
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        # Extract customer input from Connect event
        customer_input = event.get('Details', {}).get('Parameters', {}).get('customerInput', '')
        session_id = event.get('Details', {}).get('ContactData', {}).get('ContactId', 'default-session')
        
        if not customer_input:
            return {
                'statusCode': 200,
                'body': {
                    'message': 'Hello! Welcome to ABC Pharmacy. How can I help you today?',
                    'nextAction': 'CONTINUE'
                }
            }
        
        # Forward to Lex bot
        response = lex_client.recognize_text(
            botId='ABCPharmacyBot',
            botAliasId='TSTALIASID',
            localeId='en_US',
            sessionId=session_id,
            text=customer_input
        )
        
        # Process Lex response
        intent_name = response.get('sessionState', {}).get('intent', {}).get('name', '')
        bot_message = ''
        
        if response.get('messages'):
            bot_message = response['messages'][0].get('content', '')
        
        # Determine next action based on intent
        next_action = determine_next_action(intent_name, response)
        
        return {
            'statusCode': 200,
            'body': {
                'message': bot_message,
                'intent': intent_name,
                'nextAction': next_action,
                'sessionAttributes': response.get('sessionState', {}).get('sessionAttributes', {})
            }
        }
        
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return {
            'statusCode': 500,
            'body': {
                'message': 'I apologize, but I encountered an error. Please try again or speak with a representative.',
                'nextAction': 'TRANSFER_TO_AGENT'
            }
        }

def determine_next_action(intent_name: str, lex_response: Dict[str, Any]) -> str:
    """
    Determine the next action based on Lex bot response
    """
    intent_state = lex_response.get('sessionState', {}).get('intent', {}).get('state', '')
    
    if intent_name == 'PrescriptionRefill' and intent_state == 'ReadyForFulfillment':
        return 'START_PRESCRIPTION_WORKFLOW'
    elif intent_name == 'TransferToPharmacist':
        return 'TRANSFER_TO_AGENT'
    elif intent_state == 'Failed':
        return 'TRANSFER_TO_AGENT'
    else:
        return 'CONTINUE'