"""
Prescription Email Notifier Lambda Handler
Sends email notifications to customers about prescription status
"""

import json
import boto3
import logging
import os
from typing import Dict, Any
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

ses_client = boto3.client('ses')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Handle email notification requests
    """
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        notification_type = event.get('notificationType', '')
        prescription_number = event.get('prescriptionNumber', '')
        patient_name = event.get('patientName', '')
        request_id = event.get('requestId', '')
        
        if not all([notification_type, prescription_number, patient_name]):
            raise ValueError("Missing required parameters")
        
        # Get email template and send notification
        email_content = get_email_content(notification_type, event)
        result = send_email(email_content, prescription_number, patient_name)
        
        return {
            'statusCode': 200,
            'message': 'Email notification sent successfully',
            'emailId': result.get('MessageId', ''),
            'requestId': request_id
        }
        
    except Exception as e:
        logger.error(f"Error sending email notification: {str(e)}")
        return {
            'statusCode': 500,
            'error': str(e),
            'requestId': event.get('requestId', '')
        }

def get_email_content(notification_type: str, event: Dict[str, Any]) -> Dict[str, str]:
    """
    Generate email content based on notification type
    """
    prescription_number = event.get('prescriptionNumber', '')
    patient_name = event.get('patientName', '')
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    templates = {
        'SUCCESS': {
            'subject': f'Prescription {prescription_number} - Processing Complete',
            'body': f"""
Dear {patient_name},

Your prescription refill request has been processed successfully!

Prescription Number: {prescription_number}
Status: Ready for Pickup
Processing Date: {timestamp}

Your prescription is ready for pickup at ABC Pharmacy. Please bring a valid ID when collecting your medication.

Store Hours: Monday-Friday 9AM-9PM, Saturday-Sunday 9AM-6PM

Thank you for choosing ABC Pharmacy!

Best regards,
ABC Pharmacy Team
            """
        },
        'VALIDATION_FAILED': {
            'subject': f'Prescription {prescription_number} - Validation Issue',
            'body': f"""
Dear {patient_name},

We encountered an issue while processing your prescription refill request.

Prescription Number: {prescription_number}
Status: Validation Failed
Processing Date: {timestamp}

Please contact our pharmacy at (555) 123-4567 or visit us in person to resolve this issue.

Thank you for your patience.

Best regards,
ABC Pharmacy Team
            """
        },
        'PROCESSING_FAILED': {
            'subject': f'Prescription {prescription_number} - Processing Issue',
            'body': f"""
Dear {patient_name},

We encountered an issue while processing your prescription refill request.

Prescription Number: {prescription_number}
Status: Processing Failed
Processing Date: {timestamp}

Our pharmacy team has been notified and will review your request. We will contact you within 24 hours to resolve this issue.

For immediate assistance, please call us at (555) 123-4567.

Thank you for your patience.

Best regards,
ABC Pharmacy Team
            """
        }
    }
    
    return templates.get(notification_type, templates['PROCESSING_FAILED'])

def send_email(email_content: Dict[str, str], prescription_number: str, patient_name: str) -> Dict[str, Any]:
    """
    Send email using Amazon SES
    """
    from_email = os.environ.get('EMAIL_FROM_ADDRESS', 'noreply@abcpharmacy.com')
    to_email = os.environ.get('CUSTOMER_EMAIL', 'customer@example.com')  # In real implementation, get from customer data
    
    response = ses_client.send_email(
        Source=from_email,
        Destination={
            'ToAddresses': [to_email]
        },
        Message={
            'Subject': {
                'Data': email_content['subject'],
                'Charset': 'UTF-8'
            },
            'Body': {
                'Text': {
                    'Data': email_content['body'],
                    'Charset': 'UTF-8'
                }
            }
        }
    )
    
    logger.info(f"Email sent successfully. MessageId: {response['MessageId']}")
    return response