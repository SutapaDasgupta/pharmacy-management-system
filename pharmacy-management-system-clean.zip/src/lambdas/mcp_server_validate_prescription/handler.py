"""
MCP Server Validate Prescription Lambda Handler
Validates prescription data using MCP protocol
"""

import json
import boto3
import logging
import re
from typing import Dict, Any, List
from datetime import datetime, timedelta

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Mock prescription database for demonstration
PRESCRIPTION_DB = {
    'RX123456': {
        'patient_name': 'John Smith',
        'medication': 'Lisinopril 10mg',
        'prescriber': 'Dr. Johnson',
        'date_prescribed': '2024-01-15',
        'refills_remaining': 2,
        'status': 'active'
    },
    'RX789012': {
        'patient_name': 'Jane Doe',
        'medication': 'Metformin 500mg',
        'prescriber': 'Dr. Williams',
        'date_prescribed': '2024-01-20',
        'refills_remaining': 1,
        'status': 'active'
    }
}

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Handle MCP Server validation requests
    """
    try:
        logger.info(f"Received MCP request: {json.dumps(event)}")
        
        method = event.get('method', '')
        params = event.get('params', {})
        
        if method == 'validate_prescription':
            result = validate_prescription_data(params)
        elif method == 'list_methods':
            result = list_available_methods()
        else:
            raise ValueError(f"Unsupported method: {method}")
        
        return {
            'statusCode': 200,
            'method': method,
            **result
        }
        
    except Exception as e:
        logger.error(f"Error in MCP Server: {str(e)}")
        return {
            'statusCode': 500,
            'error': str(e),
            'method': event.get('method', 'unknown')
        }

def validate_prescription_data(params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate prescription using business rules and data checks
    """
    prescription_number = params.get('prescription_number', '')
    patient_name = params.get('patient_name', '')
    request_id = params.get('request_id', '')
    
    validation_results = []
    is_valid = True
    
    # Validate prescription number format
    if not validate_prescription_number_format(prescription_number):
        validation_results.append({
            'rule': 'prescription_number_format',
            'status': 'FAILED',
            'message': 'Invalid prescription number format'
        })
        is_valid = False
    else:
        validation_results.append({
            'rule': 'prescription_number_format',
            'status': 'PASSED',
            'message': 'Prescription number format is valid'
        })
    
    # Check if prescription exists in database
    prescription_data = PRESCRIPTION_DB.get(prescription_number)
    if not prescription_data:
        validation_results.append({
            'rule': 'prescription_exists',
            'status': 'FAILED',
            'message': 'Prescription not found in database'
        })
        is_valid = False
    else:
        validation_results.append({
            'rule': 'prescription_exists',
            'status': 'PASSED',
            'message': 'Prescription found in database'
        })
        
        # Validate patient name matches
        if not validate_patient_name(patient_name, prescription_data['patient_name']):
            validation_results.append({
                'rule': 'patient_name_match',
                'status': 'FAILED',
                'message': 'Patient name does not match prescription record'
            })
            is_valid = False
        else:
            validation_results.append({
                'rule': 'patient_name_match',
                'status': 'PASSED',
                'message': 'Patient name matches prescription record'
            })
        
        # Check prescription status
        if prescription_data['status'] != 'active':
            validation_results.append({
                'rule': 'prescription_status',
                'status': 'FAILED',
                'message': f'Prescription status is {prescription_data["status"]}, not active'
            })
            is_valid = False
        else:
            validation_results.append({
                'rule': 'prescription_status',
                'status': 'PASSED',
                'message': 'Prescription is active'
            })
        
        # Check refills remaining
        if prescription_data['refills_remaining'] <= 0:
            validation_results.append({
                'rule': 'refills_available',
                'status': 'FAILED',
                'message': 'No refills remaining'
            })
            is_valid = False
        else:
            validation_results.append({
                'rule': 'refills_available',
                'status': 'PASSED',
                'message': f'{prescription_data["refills_remaining"]} refills remaining'
            })
    
    return {
        'isValid': is_valid,
        'validationDetails': {
            'prescription_number': prescription_number,
            'patient_name': patient_name,
            'validation_results': validation_results,
            'prescription_data': prescription_data if prescription_data else None,
            'validated_at': datetime.now().isoformat(),
            'request_id': request_id
        }
    }

def validate_prescription_number_format(prescription_number: str) -> bool:
    """
    Validate prescription number format (RX followed by 6 digits)
    """
    pattern = r'^RX\d{6}$'
    return bool(re.match(pattern, prescription_number))

def validate_patient_name(provided_name: str, stored_name: str) -> bool:
    """
    Validate patient name with fuzzy matching
    """
    # Simple name matching - in production, use more sophisticated matching
    provided_clean = provided_name.lower().strip()
    stored_clean = stored_name.lower().strip()
    
    # Check if first name matches
    provided_parts = provided_clean.split()
    stored_parts = stored_clean.split()
    
    if len(provided_parts) > 0 and len(stored_parts) > 0:
        return provided_parts[0] == stored_parts[0]
    
    return provided_clean == stored_clean

def list_available_methods() -> Dict[str, Any]:
    """
    List available MCP methods
    """
    return {
        'methods': [
            {
                'name': 'validate_prescription',
                'description': 'Validate prescription data and eligibility for refill',
                'parameters': [
                    'prescription_number',
                    'patient_name',
                    'request_id'
                ]
            },
            {
                'name': 'list_methods',
                'description': 'List all available MCP methods',
                'parameters': []
            }
        ]
    }