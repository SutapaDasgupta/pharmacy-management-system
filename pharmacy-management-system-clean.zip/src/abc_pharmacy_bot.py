"""
ABC Pharmacy Bot (Amazon Lex)
Conversational interface for pharmacy services
"""

import json
import boto3
import logging
from typing import Dict, Any, List

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
stepfunctions_client = boto3.client('stepfunctions')
dynamodb = boto3.resource('dynamodb')

# DynamoDB table for customer data
customers_table = dynamodb.Table('pharmacy_customers')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main handler for ABC Pharmacy Bot
    
    Args:
        event: Lex event data
        context: Lambda context
        
    Returns:
        Lex response
    """
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        intent_name = event['sessionState']['intent']['name']
        session_attributes = event.get('sessionAttributes', {})
        
        # Route to appropriate intent handler
        if intent_name == 'NewPrescription':
            return handle_new_prescription(event)
        elif intent_name == 'RefillPrescription':
            return handle_refill_prescription(event)
        elif intent_name == 'CheckPrescriptionStatus':
            return handle_check_status(event)
        elif intent_name == 'GeneralInquiry':
            return handle_general_inquiry(event)
        else:
            return handle_fallback(event)
            
    except Exception as e:
        logger.error(f"Error in ABC Pharmacy Bot: {str(e)}")
        return create_error_response(event)

def handle_new_prescription(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle new prescription requests"""
    slots = event['sessionState']['intent']['slots']
    
    # Required slots for new prescription
    required_slots = ['PatientName', 'MedicationName', 'DoctorName', 'PrescriptionNumber']
    
    # Check if all required slots are filled
    missing_slots = []
    for slot in required_slots:
        if not slots.get(slot) or not slots[slot].get('value'):
            missing_slots.append(slot)
    
    if missing_slots:
        return elicit_slot(event, missing_slots[0])
    
    # All slots filled, start prescription workflow
    try:
        workflow_input = {
            'patient_name': slots['PatientName']['value']['interpretedValue'],
            'medication_name': slots['MedicationName']['value']['interpretedValue'],
            'doctor_name': slots['DoctorName']['value']['interpretedValue'],
            'prescription_number': slots['PrescriptionNumber']['value']['interpretedValue'],
            'customer_phone': event.get('sessionAttributes', {}).get('customer_number'),
            'session_id': event['sessionId']
        }
        
        # Start Step Function workflow
        response = stepfunctions_client.start_execution(
            stateMachineArn='arn:aws:states:us-east-1:123456789012:stateMachine:prescription-workflow',
            input=json.dumps(workflow_input)
        )
        
        return close_intent(
            event,
            'Fulfilled',
            f"Thank you! I've started processing your prescription for {workflow_input['medication_name']}. "
            f"You'll receive updates via text message. Your reference number is {response['executionArn'].split(':')[-1][:8]}."
        )
        
    except Exception as e:
        logger.error(f"Error starting prescription workflow: {str(e)}")
        return close_intent(
            event,
            'Failed',
            "I apologize, but there was an error processing your prescription. Please try again or speak with a pharmacist."
        )

def handle_refill_prescription(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle prescription refill requests"""
    slots = event['sessionState']['intent']['slots']
    
    if not slots.get('PrescriptionNumber') or not slots['PrescriptionNumber'].get('value'):
        return elicit_slot(event, 'PrescriptionNumber')
    
    prescription_number = slots['PrescriptionNumber']['value']['interpretedValue']
    
    # Start refill workflow
    try:
        workflow_input = {
            'prescription_number': prescription_number,
            'request_type': 'refill',
            'customer_phone': event.get('sessionAttributes', {}).get('customer_number'),
            'session_id': event['sessionId']
        }
        
        response = stepfunctions_client.start_execution(
            stateMachineArn='arn:aws:states:us-east-1:123456789012:stateMachine:prescription-workflow',
            input=json.dumps(workflow_input)
        )
        
        return close_intent(
            event,
            'Fulfilled',
            f"I've started processing your refill request for prescription {prescription_number}. "
            f"You'll receive updates via text message."
        )
        
    except Exception as e:
        logger.error(f"Error processing refill: {str(e)}")
        return close_intent(
            event,
            'Failed',
            "I apologize, but there was an error processing your refill request. Please try again."
        )

def handle_check_status(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle prescription status check requests"""
    slots = event['sessionState']['intent']['slots']
    
    if not slots.get('PrescriptionNumber') or not slots['PrescriptionNumber'].get('value'):
        return elicit_slot(event, 'PrescriptionNumber')
    
    prescription_number = slots['PrescriptionNumber']['value']['interpretedValue']
    
    # Mock status check (in real implementation, query database)
    status_messages = [
        "Your prescription is being processed and will be ready in 2 hours.",
        "Your prescription is ready for pickup at our main location.",
        "Your prescription is being reviewed by our pharmacist.",
        "Your prescription has been shipped and will arrive tomorrow."
    ]
    
    import random
    status = random.choice(status_messages)
    
    return close_intent(
        event,
        'Fulfilled',
        f"For prescription {prescription_number}: {status}"
    )

def handle_general_inquiry(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle general pharmacy inquiries"""
    return close_intent(
        event,
        'Fulfilled',
        "Our pharmacy hours are Monday-Friday 8AM-8PM, Saturday 9AM-6PM, and Sunday 10AM-4PM. "
        "We're located at 123 Main Street. Is there anything specific I can help you with?"
    )

def handle_fallback(event: Dict[str, Any]) -> Dict[str, Any]:
    """Handle fallback intent"""
    return close_intent(
        event,
        'Fulfilled',
        "I'm sorry, I didn't understand that. I can help you with new prescriptions, refills, "
        "checking prescription status, or general pharmacy information. What would you like to do?"
    )

def elicit_slot(event: Dict[str, Any], slot_name: str) -> Dict[str, Any]:
    """Elicit a specific slot from the user"""
    slot_prompts = {
        'PatientName': "What's the patient's full name?",
        'MedicationName': "What medication do you need?",
        'DoctorName': "Who is the prescribing doctor?",
        'PrescriptionNumber': "What's your prescription number?"
    }
    
    return {
        'sessionState': {
            'dialogAction': {
                'type': 'ElicitSlot',
                'slotToElicit': slot_name
            },
            'intent': event['sessionState']['intent']
        },
        'messages': [
            {
                'contentType': 'PlainText',
                'content': slot_prompts.get(slot_name, f"Please provide {slot_name}")
            }
        ]
    }

def close_intent(event: Dict[str, Any], fulfillment_state: str, message: str) -> Dict[str, Any]:
    """Close the intent with a message"""
    return {
        'sessionState': {
            'dialogAction': {
                'type': 'Close'
            },
            'intent': {
                'name': event['sessionState']['intent']['name'],
                'state': fulfillment_state
            }
        },
        'messages': [
            {
                'contentType': 'PlainText',
                'content': message
            }
        ]
    }

def create_error_response(event: Dict[str, Any]) -> Dict[str, Any]:
    """Create error response"""
    return close_intent(
        event,
        'Failed',
        "I apologize, but I'm experiencing technical difficulties. Please try again later."
    )