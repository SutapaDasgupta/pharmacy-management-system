"""
MCP Client Lambda
Client for Model Context Protocol communication with prescription validation
"""

import json
import boto3
import logging
import requests
from typing import Dict, Any, Optional

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
lambda_client = boto3.client('lambda')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main handler for MCP Client Lambda
    
    Args:
        event: Event data containing prescription information
        context: Lambda context
        
    Returns:
        MCP validation response
    """
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        action = event.get('action')
        
        if action == 'validate_prescription':
            return validate_prescription_via_mcp(event.get('prescription_data', {}))
        elif action == 'check_drug_interactions':
            return check_drug_interactions(event.get('prescription_data', {}))
        elif action == 'verify_insurance':
            return verify_insurance_coverage(event.get('prescription_data', {}))
        else:
            return create_error_response(f"Unknown action: {action}")
            
    except Exception as e:
        logger.error(f"Error in MCP Client: {str(e)}")
        return create_error_response(str(e))

def validate_prescription_via_mcp(prescription_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate prescription using MCP Server
    
    Args:
        prescription_data: Prescription information
        
    Returns:
        Validation response
    """
    try:
        # Call MCP Server Lambda for validation
        mcp_payload = {
            'method': 'validate_prescription',
            'params': {
                'prescription': {
                    'patient_name': prescription_data.get('patient_name'),
                    'medication_name': prescription_data.get('medication_name'),
                    'doctor_name': prescription_data.get('doctor_name'),
                    'prescription_number': prescription_data.get('prescription_number'),
                    'dosage': prescription_data.get('dosage'),
                    'quantity': prescription_data.get('quantity'),
                    'refills': prescription_data.get('refills', 0)
                }
            }
        }
        
        # Invoke MCP Server Lambda
        response = lambda_client.invoke(
            FunctionName='mcp-server-validate-prescription-lambda',
            InvocationType='RequestResponse',
            Payload=json.dumps(mcp_payload)
        )
        
        response_payload = json.loads(response['Payload'].read())
        
        if response_payload.get('statusCode') == 200:
            mcp_result = json.loads(response_payload['body'])
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'validation_passed': mcp_result.get('valid', False),
                    'validation_details': mcp_result.get('details', {}),
                    'warnings': mcp_result.get('warnings', []),
                    'errors': mcp_result.get('errors', [])
                })
            }
        else:
            return create_error_response("MCP Server validation failed")
            
    except Exception as e:
        logger.error(f"Error validating prescription via MCP: {str(e)}")
        return create_error_response(f"MCP validation error: {str(e)}")

def check_drug_interactions(prescription_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check for drug interactions using MCP Server
    
    Args:
        prescription_data: Prescription information
        
    Returns:
        Drug interaction check response
    """
    try:
        mcp_payload = {
            'method': 'check_drug_interactions',
            'params': {
                'medication': prescription_data.get('medication_name'),
                'patient_medications': prescription_data.get('current_medications', []),
                'patient_allergies': prescription_data.get('allergies', [])
            }
        }
        
        response = lambda_client.invoke(
            FunctionName='mcp-server-validate-prescription-lambda',
            InvocationType='RequestResponse',
            Payload=json.dumps(mcp_payload)
        )
        
        response_payload = json.loads(response['Payload'].read())
        
        if response_payload.get('statusCode') == 200:
            mcp_result = json.loads(response_payload['body'])
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'interactions_found': mcp_result.get('interactions_found', False),
                    'interactions': mcp_result.get('interactions', []),
                    'severity_levels': mcp_result.get('severity_levels', []),
                    'recommendations': mcp_result.get('recommendations', [])
                })
            }
        else:
            return create_error_response("Drug interaction check failed")
            
    except Exception as e:
        logger.error(f"Error checking drug interactions: {str(e)}")
        return create_error_response(f"Drug interaction check error: {str(e)}")

def verify_insurance_coverage(prescription_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Verify insurance coverage using MCP Server
    
    Args:
        prescription_data: Prescription information
        
    Returns:
        Insurance verification response
    """
    try:
        mcp_payload = {
            'method': 'verify_insurance',
            'params': {
                'medication': prescription_data.get('medication_name'),
                'insurance_info': prescription_data.get('insurance_info', {}),
                'patient_id': prescription_data.get('patient_id')
            }
        }
        
        response = lambda_client.invoke(
            FunctionName='mcp-server-validate-prescription-lambda',
            InvocationType='RequestResponse',
            Payload=json.dumps(mcp_payload)
        )
        
        response_payload = json.loads(response['Payload'].read())
        
        if response_payload.get('statusCode') == 200:
            mcp_result = json.loads(response_payload['body'])
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'coverage_verified': mcp_result.get('covered', False),
                    'copay_amount': mcp_result.get('copay', 0),
                    'coverage_details': mcp_result.get('coverage_details', {}),
                    'prior_authorization_required': mcp_result.get('prior_auth_required', False)
                })
            }
        else:
            return create_error_response("Insurance verification failed")
            
    except Exception as e:
        logger.error(f"Error verifying insurance: {str(e)}")
        return create_error_response(f"Insurance verification error: {str(e)}")

def create_mcp_request(method: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Create standardized MCP request
    
    Args:
        method: MCP method name
        params: Method parameters
        
    Returns:
        MCP request payload
    """
    return {
        'jsonrpc': '2.0',
        'id': 1,
        'method': method,
        'params': params
    }

def create_error_response(error_message: str) -> Dict[str, Any]:
    """
    Create error response
    
    Args:
        error_message: Error description
        
    Returns:
        Error response
    """
    return {
        'statusCode': 500,
        'body': json.dumps({
            'validation_passed': False,
            'error': error_message,
            'timestamp': context.aws_request_id if 'context' in globals() else 'unknown'
        })
    }