"""
Prescription Email Notifier Lambda
Sends email notifications for prescription status updates
"""

import json
import boto3
import logging
from typing import Dict, Any, List
from datetime import datetime

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
ses_client = boto3.client('ses')
sns_client = boto3.client('sns')

# Configuration
SENDER_EMAIL = 'noreply@abcpharmacy.com'
PHARMACY_NAME = 'ABC Pharmacy'
PHARMACY_PHONE = '(555) 123-4567'

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main handler for Prescription Email Notifier Lambda
    
    Args:
        event: Event data containing notification details
        context: Lambda context
        
    Returns:
        Notification response
    """
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        action = event.get('action')
        
        if action == 'send_success_notification':
            return send_success_notification(event)
        elif action == 'send_error_notification':
            return send_error_notification(event)
        elif action == 'send_status_update':
            return send_status_update(event)
        elif action == 'send_ready_notification':
            return send_ready_notification(event)
        else:
            return create_error_response(f"Unknown action: {action}")
            
    except Exception as e:
        logger.error(f"Error in Email Notifier: {str(e)}")
        return create_error_response(str(e))

def send_success_notification(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Send success notification for prescription processing
    
    Args:
        event: Event containing prescription and processing data
        
    Returns:
        Notification response
    """
    try:
        prescription_data = event.get('prescription_data', {})
        processing_result = event.get('processing_result', {})
        
        patient_name = prescription_data.get('patient_name', 'Valued Customer')
        medication_name = prescription_data.get('medication_name', 'your medication')
        prescription_number = prescription_data.get('prescription_number', 'N/A')
        customer_phone = prescription_data.get('customer_phone')
        
        # Email content
        subject = f"Prescription Processed Successfully - {prescription_number}"
        
        html_body = f"""
        <html>
        <body>
            <h2>Prescription Processing Confirmation</h2>
            <p>Dear {patient_name},</p>
            
            <p>Your prescription has been successfully processed!</p>
            
            <div style="background-color: #f0f8ff; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3>Prescription Details:</h3>
                <ul>
                    <li><strong>Prescription Number:</strong> {prescription_number}</li>
                    <li><strong>Medication:</strong> {medication_name}</li>
                    <li><strong>Status:</strong> Processing Complete</li>
                    <li><strong>Estimated Ready Time:</strong> {processing_result.get('estimated_ready_time', '2-3 hours')}</li>
                </ul>
            </div>
            
            <p>We'll send you another notification when your prescription is ready for pickup.</p>
            
            <p><strong>Pickup Location:</strong><br>
            {PHARMACY_NAME}<br>
            123 Main Street<br>
            Anytown, ST 12345</p>
            
            <p><strong>Pharmacy Hours:</strong><br>
            Monday-Friday: 8:00 AM - 8:00 PM<br>
            Saturday: 9:00 AM - 6:00 PM<br>
            Sunday: 10:00 AM - 4:00 PM</p>
            
            <p>If you have any questions, please call us at {PHARMACY_PHONE}.</p>
            
            <p>Thank you for choosing {PHARMACY_NAME}!</p>
            
            <p><em>This is an automated message. Please do not reply to this email.</em></p>
        </body>
        </html>
        """
        
        text_body = f"""
        Prescription Processing Confirmation
        
        Dear {patient_name},
        
        Your prescription has been successfully processed!
        
        Prescription Details:
        - Prescription Number: {prescription_number}
        - Medication: {medication_name}
        - Status: Processing Complete
        - Estimated Ready Time: {processing_result.get('estimated_ready_time', '2-3 hours')}
        
        We'll send you another notification when your prescription is ready for pickup.
        
        Pickup Location:
        {PHARMACY_NAME}
        123 Main Street
        Anytown, ST 12345
        
        Pharmacy Hours:
        Monday-Friday: 8:00 AM - 8:00 PM
        Saturday: 9:00 AM - 6:00 PM
        Sunday: 10:00 AM - 4:00 PM
        
        If you have any questions, please call us at {PHARMACY_PHONE}.
        
        Thank you for choosing {PHARMACY_NAME}!
        """
        
        # Send email
        email_response = send_email(
            recipient=prescription_data.get('email', 'customer@example.com'),
            subject=subject,
            html_body=html_body,
            text_body=text_body
        )
        
        # Send SMS if phone number provided
        sms_response = None
        if customer_phone:
            sms_message = f"{PHARMACY_NAME}: Your prescription {prescription_number} for {medication_name} is being processed. Estimated ready time: {processing_result.get('estimated_ready_time', '2-3 hours')}. We'll notify you when ready."
            sms_response = send_sms(customer_phone, sms_message)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Success notification sent',
                'email_sent': email_response.get('success', False),
                'sms_sent': sms_response.get('success', False) if sms_response else False
            })
        }
        
    except Exception as e:
        logger.error(f"Error sending success notification: {str(e)}")
        return create_error_response(f"Success notification error: {str(e)}")

def send_error_notification(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Send error notification for prescription processing failures
    
    Args:
        event: Event containing error details
        
    Returns:
        Notification response
    """
    try:
        prescription_data = event.get('prescription_data', {})
        error_type = event.get('error_type', 'unknown')
        error_details = event.get('error_details', {})
        
        patient_name = prescription_data.get('patient_name', 'Valued Customer')
        prescription_number = prescription_data.get('prescription_number', 'N/A')
        customer_phone = prescription_data.get('customer_phone')
        
        # Error-specific messages
        error_messages = {
            'validation': 'There was an issue with your prescription information.',
            'mcp_error': 'We encountered a technical issue during validation.',
            'mcp_validation_failed': 'Your prescription could not be validated.',
            'processing': 'There was an error processing your prescription.'
        }
        
        error_message = error_messages.get(error_type, 'An unexpected error occurred.')
        
        subject = f"Prescription Processing Issue - {prescription_number}"
        
        html_body = f"""
        <html>
        <body>
            <h2>Prescription Processing Update</h2>
            <p>Dear {patient_name},</p>
            
            <p>We encountered an issue while processing your prescription.</p>
            
            <div style="background-color: #fff3cd; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #ffc107;">
                <h3>Issue Details:</h3>
                <ul>
                    <li><strong>Prescription Number:</strong> {prescription_number}</li>
                    <li><strong>Issue:</strong> {error_message}</li>
                </ul>
            </div>
            
            <p><strong>Next Steps:</strong></p>
            <ul>
                <li>Please contact our pharmacy at {PHARMACY_PHONE}</li>
                <li>Have your prescription number ready: {prescription_number}</li>
                <li>Our pharmacists will help resolve this issue</li>
            </ul>
            
            <p>We apologize for any inconvenience and appreciate your patience.</p>
            
            <p>Thank you for choosing {PHARMACY_NAME}!</p>
            
            <p><em>This is an automated message. Please do not reply to this email.</em></p>
        </body>
        </html>
        """
        
        # Send email
        email_response = send_email(
            recipient=prescription_data.get('email', 'customer@example.com'),
            subject=subject,
            html_body=html_body,
            text_body=f"Prescription Processing Issue\n\nDear {patient_name},\n\nWe encountered an issue with prescription {prescription_number}: {error_message}\n\nPlease call us at {PHARMACY_PHONE} for assistance.\n\nThank you,\n{PHARMACY_NAME}"
        )
        
        # Send SMS if phone number provided
        sms_response = None
        if customer_phone:
            sms_message = f"{PHARMACY_NAME}: Issue with prescription {prescription_number}. Please call {PHARMACY_PHONE} for assistance."
            sms_response = send_sms(customer_phone, sms_message)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Error notification sent',
                'email_sent': email_response.get('success', False),
                'sms_sent': sms_response.get('success', False) if sms_response else False
            })
        }
        
    except Exception as e:
        logger.error(f"Error sending error notification: {str(e)}")
        return create_error_response(f"Error notification error: {str(e)}")

def send_ready_notification(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Send notification when prescription is ready for pickup
    
    Args:
        event: Event containing prescription ready details
        
    Returns:
        Notification response
    """
    try:
        prescription_data = event.get('prescription_data', {})
        
        patient_name = prescription_data.get('patient_name', 'Valued Customer')
        medication_name = prescription_data.get('medication_name', 'your medication')
        prescription_number = prescription_data.get('prescription_number', 'N/A')
        customer_phone = prescription_data.get('customer_phone')
        
        subject = f"Prescription Ready for Pickup - {prescription_number}"
        
        html_body = f"""
        <html>
        <body>
            <h2>Your Prescription is Ready!</h2>
            <p>Dear {patient_name},</p>
            
            <p>Great news! Your prescription is ready for pickup.</p>
            
            <div style="background-color: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0; border-left: 4px solid #28a745;">
                <h3>Ready for Pickup:</h3>
                <ul>
                    <li><strong>Prescription Number:</strong> {prescription_number}</li>
                    <li><strong>Medication:</strong> {medication_name}</li>
                    <li><strong>Status:</strong> Ready for Pickup</li>
                </ul>
            </div>
            
            <p><strong>Pickup Information:</strong></p>
            <ul>
                <li>Please bring a valid ID</li>
                <li>We'll hold your prescription for 14 days</li>
                <li>Drive-thru and walk-in service available</li>
            </ul>
            
            <p><strong>Pickup Location:</strong><br>
            {PHARMACY_NAME}<br>
            123 Main Street<br>
            Anytown, ST 12345</p>
            
            <p><strong>Pharmacy Hours:</strong><br>
            Monday-Friday: 8:00 AM - 8:00 PM<br>
            Saturday: 9:00 AM - 6:00 PM<br>
            Sunday: 10:00 AM - 4:00 PM</p>
            
            <p>Thank you for choosing {PHARMACY_NAME}!</p>
            
            <p><em>This is an automated message. Please do not reply to this email.</em></p>
        </body>
        </html>
        """
        
        # Send email
        email_response = send_email(
            recipient=prescription_data.get('email', 'customer@example.com'),
            subject=subject,
            html_body=html_body,
            text_body=f"Your prescription {prescription_number} for {medication_name} is ready for pickup at {PHARMACY_NAME}. Please bring valid ID."
        )
        
        # Send SMS
        sms_response = None
        if customer_phone:
            sms_message = f"{PHARMACY_NAME}: Your prescription {prescription_number} for {medication_name} is ready for pickup! Bring valid ID. Hours: M-F 8AM-8PM, Sat 9AM-6PM, Sun 10AM-4PM."
            sms_response = send_sms(customer_phone, sms_message)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Ready notification sent',
                'email_sent': email_response.get('success', False),
                'sms_sent': sms_response.get('success', False) if sms_response else False
            })
        }
        
    except Exception as e:
        logger.error(f"Error sending ready notification: {str(e)}")
        return create_error_response(f"Ready notification error: {str(e)}")

def send_email(recipient: str, subject: str, html_body: str, text_body: str) -> Dict[str, Any]:
    """
    Send email using SES
    
    Args:
        recipient: Email recipient
        subject: Email subject
        html_body: HTML email body
        text_body: Plain text email body
        
    Returns:
        Email send response
    """
    try:
        response = ses_client.send_email(
            Source=SENDER_EMAIL,
            Destination={'ToAddresses': [recipient]},
            Message={
                'Subject': {'Data': subject},
                'Body': {
                    'Html': {'Data': html_body},
                    'Text': {'Data': text_body}
                }
            }
        )
        
        return {
            'success': True,
            'message_id': response['MessageId']
        }
        
    except Exception as e:
        logger.error(f"Error sending email: {str(e)}")
        return {
            'success': False,
            'error': str(e)
        }

def send_sms(phone_number: str, message: str) -> Dict[str, Any]:
    """
    Send SMS using SNS
    
    Args:
        phone_number: Phone number to send SMS to
        message: SMS message content
        
    Returns:
        SMS send response
    """
    try:
        # Format phone number (ensure it starts with +1 for US numbers)
        if not phone_number.startswith('+'):
            phone_number = f"+1{phone_number.replace('-', '').replace('(', '').replace(')', '').replace(' ', '')}"
        
        response = sns_client.publish(
            PhoneNumber=phone_number,
            Message=message
        )
        
        return {
            'success': True,
            'message_id': response['MessageId']
        }
        
    except Exception as e:
        logger.error(f"Error sending SMS: {str(e)}")
        return {
            'success': False,
            'error': str(e)
        }

def send_status_update(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Send general status update notification
    
    Args:
        event: Event containing status update details
        
    Returns:
        Notification response
    """
    # Implementation for general status updates
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Status update sent'
        })
    }

def create_error_response(error_message: str) -> Dict[str, Any]:
    """
    Create error response
    
    Args:
        error_message: Error description
        
    Returns:
        Error response
    """
    return {
        'statusCode': 500,
        'body': json.dumps({
            'error': error_message,
            'timestamp': datetime.utcnow().isoformat()
        })
    }