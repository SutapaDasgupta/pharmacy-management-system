"""
Prescription Processor Lambda
Core prescription processing logic and workflow management
"""

import json
import boto3
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import uuid

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')
stepfunctions_client = boto3.client('stepfunctions')

# DynamoDB tables
prescriptions_table = dynamodb.Table('prescriptions')
patients_table = dynamodb.Table('patients')
inventory_table = dynamodb.Table('inventory')

def lambda_handler(event: Dict[str, Any], context) -> Dict[str, Any]:
    """
    Main handler for Prescription Processor Lambda
    
    Args:
        event: Event data containing prescription processing request
        context: Lambda context
        
    Returns:
        Processing response
    """
    try:
        logger.info(f"Received event: {json.dumps(event)}")
        
        action = event.get('action')
        data = event.get('data', {})
        
        if action == 'validate_input':
            return validate_input(data)
        elif action == 'process_prescription':
            return process_prescription(data)
        elif action == 'check_inventory':
            return check_inventory(data)
        elif action == 'update_status':
            return update_prescription_status(data)
        elif action == 'calculate_pricing':
            return calculate_pricing(data)
        else:
            return create_error_response(f"Unknown action: {action}")
            
    except Exception as e:
        logger.error(f"Error in Prescription Processor: {str(e)}")
        return create_error_response(str(e))

def validate_input(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate prescription input data
    
    Args:
        data: Prescription data to validate
        
    Returns:
        Validation response
    """
    try:
        validation_result = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'normalized_data': {}
        }
        
        # Required fields validation
        required_fields = ['patient_name', 'medication_name', 'prescription_number']
        for field in required_fields:
            if not data.get(field):
                validation_result['errors'].append(f"Missing required field: {field}")
                validation_result['valid'] = False
        
        # Normalize and validate patient name
        if data.get('patient_name'):
            normalized_name = normalize_patient_name(data['patient_name'])
            validation_result['normalized_data']['patient_name'] = normalized_name
            
            # Check if patient exists
            patient_info = get_patient_info(normalized_name)
            if patient_info:
                validation_result['normalized_data']['patient_info'] = patient_info
            else:
                validation_result['warnings'].append("Patient not found in database - new patient")
        
        # Normalize medication name
        if data.get('medication_name'):
            normalized_medication = normalize_medication_name(data['medication_name'])
            validation_result['normalized_data']['medication_name'] = normalized_medication
        
        # Validate prescription number format
        if data.get('prescription_number'):
            if not validate_prescription_number_format(data['prescription_number']):
                validation_result['errors'].append("Invalid prescription number format")
                validation_result['valid'] = False
            else:
                validation_result['normalized_data']['prescription_number'] = data['prescription_number'].upper()
        
        # Validate doctor information if provided
        if data.get('doctor_name'):
            doctor_validation = validate_doctor_format(data['doctor_name'])
            if not doctor_validation['valid']:
                validation_result['warnings'].extend(doctor_validation['warnings'])
            validation_result['normalized_data']['doctor_name'] = doctor_validation['normalized_name']
        
        # Add processing metadata
        validation_result['normalized_data']['processing_id'] = str(uuid.uuid4())
        validation_result['normalized_data']['created_at'] = datetime.utcnow().isoformat()
        validation_result['normalized_data']['status'] = 'validated'
        
        return {
            'statusCode': 200,
            'body': json.dumps(validation_result)
        }
        
    except Exception as e:
        logger.error(f"Error validating input: {str(e)}")
        return create_error_response(f"Input validation error: {str(e)}")

def process_prescription(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process prescription through the complete workflow
    
    Args:
        data: Validated prescription data
        
    Returns:
        Processing response
    """
    try:
        processing_id = data.get('processing_id') or str(uuid.uuid4())
        
        # Extract prescription details
        prescription_data = {
            'processing_id': processing_id,
            'patient_name': data.get('patient_name'),
            'medication_name': data.get('medication_name'),
            'prescription_number': data.get('prescription_number'),
            'doctor_name': data.get('doctor_name'),
            'dosage': data.get('dosage'),
            'quantity': data.get('quantity', 30),
            'refills': data.get('refills', 0),
            'customer_phone': data.get('customer_phone'),
            'session_id': data.get('session_id'),
            'status': 'processing',
            'created_at': datetime.utcnow().isoformat(),
            'updated_at': datetime.utcnow().isoformat()
        }
        
        # Save prescription to database
        save_result = save_prescription_to_database(prescription_data)
        if not save_result['success']:
            return create_error_response(f"Failed to save prescription: {save_result['error']}")
        
        # Check inventory availability
        inventory_result = check_medication_inventory(
            prescription_data['medication_name'],
            prescription_data['quantity']
        )
        
        if not inventory_result['available']:
            # Update status to pending inventory
            update_prescription_status({
                'processing_id': processing_id,
                'status': 'pending_inventory',
                'notes': f"Insufficient inventory. Available: {inventory_result['available_quantity']}, Needed: {prescription_data['quantity']}"
            })
            
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'processing_id': processing_id,
                    'status': 'pending_inventory',
                    'message': 'Prescription saved but pending inventory availability',
                    'inventory_info': inventory_result,
                    'estimated_ready_time': 'Pending inventory restock'
                })
            }
        
        # Calculate pricing
        pricing_result = calculate_prescription_pricing(prescription_data)
        prescription_data['pricing'] = pricing_result
        
        # Reserve inventory
        reservation_result = reserve_inventory(
            prescription_data['medication_name'],
            prescription_data['quantity'],
            processing_id
        )
        
        if not reservation_result['success']:
            return create_error_response(f"Failed to reserve inventory: {reservation_result['error']}")
        
        # Update prescription status to ready for fulfillment
        update_prescription_status({
            'processing_id': processing_id,
            'status': 'ready_for_fulfillment',
            'pricing': pricing_result,
            'inventory_reserved': True,
            'estimated_ready_time': calculate_ready_time()
        })
        
        # Schedule fulfillment (in real implementation, this might trigger another workflow)
        fulfillment_result = schedule_fulfillment(prescription_data)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'processing_id': processing_id,
                'status': 'processed',
                'message': 'Prescription processed successfully',
                'pricing': pricing_result,
                'estimated_ready_time': calculate_ready_time(),
                'fulfillment_scheduled': fulfillment_result['scheduled']
            })
        }
        
    except Exception as e:
        logger.error(f"Error processing prescription: {str(e)}")
        return create_error_response(f"Prescription processing error: {str(e)}")

def check_inventory(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check medication inventory availability
    
    Args:
        data: Inventory check request data
        
    Returns:
        Inventory check response
    """
    try:
        medication_name = data.get('medication_name')
        quantity_needed = data.get('quantity', 1)
        
        inventory_result = check_medication_inventory(medication_name, quantity_needed)
        
        return {
            'statusCode': 200,
            'body': json.dumps(inventory_result)
        }
        
    except Exception as e:
        logger.error(f"Error checking inventory: {str(e)}")
        return create_error_response(f"Inventory check error: {str(e)}")

def calculate_pricing(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Calculate prescription pricing
    
    Args:
        data: Pricing calculation request data
        
    Returns:
        Pricing response
    """
    try:
        pricing_result = calculate_prescription_pricing(data)
        
        return {
            'statusCode': 200,
            'body': json.dumps(pricing_result)
        }
        
    except Exception as e:
        logger.error(f"Error calculating pricing: {str(e)}")
        return create_error_response(f"Pricing calculation error: {str(e)}")

def normalize_patient_name(name: str) -> str:
    """Normalize patient name format"""
    return ' '.join(word.capitalize() for word in name.strip().split())

def normalize_medication_name(medication: str) -> str:
    """Normalize medication name format"""
    return medication.strip().lower()

def validate_prescription_number_format(prescription_number: str) -> bool:
    """Validate prescription number format"""
    import re
    # Prescription numbers should be 8-12 alphanumeric characters
    return bool(re.match(r'^[A-Z0-9]{8,12}$', prescription_number.upper()))

def validate_doctor_format(doctor_name: str) -> Dict[str, Any]:
    """Validate and normalize doctor name format"""
    normalized_name = doctor_name.strip()
    
    # Add "Dr." prefix if not present
    if not normalized_name.lower().startswith('dr.'):
        normalized_name = f"Dr. {normalized_name}"
    
    return {
        'valid': True,
        'normalized_name': normalized_name,
        'warnings': []
    }

def get_patient_info(patient_name: str) -> Optional[Dict[str, Any]]:
    """Get patient information from database"""
    try:
        # Mock patient lookup (would query DynamoDB in real implementation)
        return None  # Assume new patient for demo
    except Exception as e:
        logger.error(f"Error getting patient info: {str(e)}")
        return None

def save_prescription_to_database(prescription_data: Dict[str, Any]) -> Dict[str, Any]:
    """Save prescription to DynamoDB"""
    try:
        # In real implementation, save to DynamoDB
        # For demo, just return success
        return {
            'success': True,
            'prescription_id': prescription_data['processing_id']
        }
    except Exception as e:
        logger.error(f"Error saving prescription: {str(e)}")
        return {
            'success': False,
            'error': str(e)
        }

def check_medication_inventory(medication_name: str, quantity_needed: int) -> Dict[str, Any]:
    """Check medication inventory availability"""
    try:
        # Mock inventory check
        mock_inventory = {
            'amoxicillin': 100,
            'lisinopril': 50,
            'metformin': 75,
            'oxycodone': 25
        }
        
        available_quantity = mock_inventory.get(medication_name.lower(), 0)
        
        return {
            'available': available_quantity >= quantity_needed,
            'available_quantity': available_quantity,
            'quantity_needed': quantity_needed,
            'medication_name': medication_name
        }
        
    except Exception as e:
        logger.error(f"Error checking inventory: {str(e)}")
        return {
            'available': False,
            'error': str(e)
        }

def calculate_prescription_pricing(prescription_data: Dict[str, Any]) -> Dict[str, Any]:
    """Calculate prescription pricing"""
    try:
        # Mock pricing calculation
        base_prices = {
            'amoxicillin': 15.99,
            'lisinopril': 12.50,
            'metformin': 8.75,
            'oxycodone': 45.00
        }
        
        medication_name = prescription_data.get('medication_name', '').lower()
        quantity = prescription_data.get('quantity', 30)
        
        base_price = base_prices.get(medication_name, 25.00)
        subtotal = base_price * (quantity / 30)  # Normalize to 30-day supply
        
        # Add dispensing fee
        dispensing_fee = 5.00
        
        # Calculate tax
        tax_rate = 0.08
        tax = (subtotal + dispensing_fee) * tax_rate
        
        total = subtotal + dispensing_fee + tax
        
        return {
            'medication_cost': round(subtotal, 2),
            'dispensing_fee': dispensing_fee,
            'tax': round(tax, 2),
            'total': round(total, 2),
            'quantity': quantity,
            'unit_price': base_price
        }
        
    except Exception as e:
        logger.error(f"Error calculating pricing: {str(e)}")
        return {
            'error': str(e)
        }

def reserve_inventory(medication_name: str, quantity: int, processing_id: str) -> Dict[str, Any]:
    """Reserve inventory for prescription"""
    try:
        # Mock inventory reservation
        return {
            'success': True,
            'reservation_id': f"RES-{processing_id[:8]}",
            'reserved_quantity': quantity,
            'medication_name': medication_name
        }
        
    except Exception as e:
        logger.error(f"Error reserving inventory: {str(e)}")
        return {
            'success': False,
            'error': str(e)
        }

def update_prescription_status(data: Dict[str, Any]) -> Dict[str, Any]:
    """Update prescription status in database"""
    try:
        processing_id = data.get('processing_id')
        status = data.get('status')
        
        # Mock status update
        logger.info(f"Updating prescription {processing_id} status to {status}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'updated': True,
                'processing_id': processing_id,
                'new_status': status
            })
        }
        
    except Exception as e:
        logger.error(f"Error updating status: {str(e)}")
        return create_error_response(f"Status update error: {str(e)}")

def schedule_fulfillment(prescription_data: Dict[str, Any]) -> Dict[str, Any]:
    """Schedule prescription fulfillment"""
    try:
        # Mock fulfillment scheduling
        return {
            'scheduled': True,
            'fulfillment_id': f"FUL-{prescription_data['processing_id'][:8]}",
            'estimated_completion': calculate_ready_time()
        }
        
    except Exception as e:
        logger.error(f"Error scheduling fulfillment: {str(e)}")
        return {
            'scheduled': False,
            'error': str(e)
        }

def calculate_ready_time() -> str:
    """Calculate estimated ready time"""
    ready_time = datetime.utcnow() + timedelta(hours=2)
    return ready_time.strftime("%I:%M %p today")

def create_error_response(error_message: str) -> Dict[str, Any]:
    """Create error response"""
    return {
        'statusCode': 500,
        'body': json.dumps({
            'error': error_message,
            'timestamp': datetime.utcnow().isoformat()
        })
    }