# Pharmacy Management System

A comprehensive pharmacy management system built on AWS with the following components:

## Architecture Overview

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ Pharmacy Entry  │───▶│ ABC Pharmacy Bot │───▶│ Prescription    │
│ Flow (Connect)  │    │ (Lex)           │    │ Workflow        │
└─────────────────┘    └──────────────────┘    │ (Step Function) │
                                               └─────────────────┘
                                                        │
                       ┌─────────────────────────────────┼─────────────────────────────────┐
                       │                                 │                                 │
                       ▼                                 ▼                                 ▼
              ┌─────────────────┐              ┌─────────────────┐              ┌─────────────────┐
              │ MCP Client      │              │ Prescription    │              │ Email Notifier  │
              │ Lambda          │              │ Processor       │              │ Lambda          │
              └─────────────────┘              │ Lambda          │              └─────────────────┘
                       │                       └─────────────────┘
                       ▼
              ┌─────────────────┐
              │ MCP Server      │
              │ Validate        │
              │ Prescription    │
              └─────────────────┘
```

## Components

### 1. Pharmacy_EntryFlow (Amazon Connect)
- **Purpose**: Initial customer contact point
- **Function**: Routes calls to appropriate services
- **Integration**: Connects to ABC Pharmacy Bot

### 2. Pharmacy_EntryFlow Lambda
- **Purpose**: Handles Connect call flow logic
- **Function**: Processes customer requests and routes to Lex bot
- **File**: `src/pharmacy_entry_flow_lambda.py`

### 3. ABC Pharmacy Bot (Amazon Lex)
- **Purpose**: Conversational interface for pharmacy services
- **Function**: Handles customer interactions, prescription requests
- **File**: `src/abc_pharmacy_bot.py`

### 4. Prescription Workflow (Step Function)
- **Purpose**: Orchestrates prescription processing workflow
- **Function**: Coordinates validation, processing, and notification
- **File**: `src/prescription_workflow.json`

### 5. MCP Client Lambda
- **Purpose**: Client for Model Context Protocol communication
- **Function**: Interfaces with MCP servers for prescription validation
- **File**: `src/mcp_client_lambda.py`

### 6. Prescription Email Notifier Lambda
- **Purpose**: Sends email notifications
- **Function**: Notifies customers about prescription status
- **File**: `src/prescription_email_notifier_lambda.py`

### 7. MCP Server Validate Prescription Lambda
- **Purpose**: MCP server for prescription validation
- **Function**: Validates prescription data and requirements
- **File**: `src/mcp_server_validate_prescription_lambda.py`

### 8. Prescription Processor Lambda
- **Purpose**: Core prescription processing logic
- **Function**: Processes and validates prescription requests
- **File**: `src/prescription_processor_lambda.py`

## Setup and Deployment

1. Install dependencies: `pip install -r requirements.txt`
2. Configure AWS credentials
3. Run deployment script: `python deploy/deploy_all.py`

## Testing

Run tests with: `python -m pytest tests/`

## Environment Variables

Copy `.env.example` to `.env` and configure your environment variables.