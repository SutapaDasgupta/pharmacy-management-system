#!/bin/bash

# GitHub Setup Script for Pharmacy Management System
# Usage: ./setup_github.sh YOUR_GITHUB_USERNAME

if [ $# -eq 0 ]; then
    echo "Usage: $0 <github_username>"
    echo "Example: $0 johndoe"
    exit 1
fi

GITHUB_USERNAME=$1
REPO_NAME="pharmacy-management-system"
REPO_URL="https://github.com/${GITHUB_USERNAME}/${REPO_NAME}.git"

echo "Setting up GitHub repository..."
echo "Repository URL: ${REPO_URL}"
echo ""

# Check if remote origin already exists
if git remote get-url origin > /dev/null 2>&1; then
    echo "Remote origin already exists. Removing it..."
    git remote remove origin
fi

# Add the GitHub repository as remote origin
echo "Adding GitHub repository as remote origin..."
git remote add origin "${REPO_URL}"

# Verify the remote was added
echo "Verifying remote repository..."
git remote -v

# Push to GitHub
echo ""
echo "Pushing to GitHub..."
git push -u origin main

echo ""
echo "✅ GitHub setup complete!"
echo "Your repository is now available at: https://github.com/${GITHUB_USERNAME}/${REPO_NAME}"
echo ""
echo "Repository contains:"
echo "  📁 src/ - 6 Lambda functions"
echo "  📁 docs/ - Architecture and API documentation"
echo "  📁 tests/ - Comprehensive test suite"
echo "  📁 deploy/ - Deployment scripts"
echo "  📄 README.md - Project overview"
echo "  📄 requirements.txt - Dependencies"
echo "  📄 .env.example - Configuration template"