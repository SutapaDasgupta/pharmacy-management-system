"""
Deploy All Components
Master deployment script for the entire pharmacy system
"""

import boto3
import json
import time
import logging
from typing import Dict, Any

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize AWS clients
lambda_client = boto3.client('lambda')
stepfunctions_client = boto3.client('stepfunctions')
lex_client = boto3.client('lexv2-models')
connect_client = boto3.client('connect')
iam_client = boto3.client('iam')

def main():
    """Main deployment function"""
    try:
        logger.info("Starting deployment of Pharmacy Management System...")
        
        # Step 1: Create IAM roles
        logger.info("Creating IAM roles...")
        iam_roles = create_iam_roles()
        
        # Step 2: Deploy Lambda functions
        logger.info("Deploying Lambda functions...")
        lambda_functions = deploy_lambda_functions(iam_roles)
        
        # Step 3: Deploy Step Function
        logger.info("Deploying Step Function...")
        step_function = deploy_step_function(lambda_functions, iam_roles)
        
        # Step 4: Deploy Lex Bot
        logger.info("Deploying Lex Bot...")
        lex_bot = deploy_lex_bot(lambda_functions)
        
        # Step 5: Configure Connect Flow
        logger.info("Configuring Connect Flow...")
        connect_flow = configure_connect_flow(lambda_functions, lex_bot)
        
        # Step 6: Create DynamoDB tables
        logger.info("Creating DynamoDB tables...")
        dynamodb_tables = create_dynamodb_tables()
        
        logger.info("Deployment completed successfully!")
        
        # Print deployment summary
        print_deployment_summary({
            'iam_roles': iam_roles,
            'lambda_functions': lambda_functions,
            'step_function': step_function,
            'lex_bot': lex_bot,
            'connect_flow': connect_flow,
            'dynamodb_tables': dynamodb_tables
        })
        
    except Exception as e:
        logger.error(f"Deployment failed: {str(e)}")
        raise

def create_iam_roles() -> Dict[str, str]:
    """Create IAM roles for all services"""
    roles = {}
    
    # Lambda execution role
    lambda_role_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {"Service": "lambda.amazonaws.com"},
                "Action": "sts:AssumeRole"
            }
        ]
    }
    
    try:
        lambda_role = iam_client.create_role(
            RoleName='PharmacyLambdaExecutionRole',
            AssumeRolePolicyDocument=json.dumps(lambda_role_policy),
            Description='Execution role for Pharmacy Lambda functions'
        )
        roles['lambda_role'] = lambda_role['Role']['Arn']
        
        # Attach policies
        iam_client.attach_role_policy(
            RoleName='PharmacyLambdaExecutionRole',
            PolicyArn='arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole'
        )
        
    except iam_client.exceptions.EntityAlreadyExistsException:
        # Role already exists
        role = iam_client.get_role(RoleName='PharmacyLambdaExecutionRole')
        roles['lambda_role'] = role['Role']['Arn']
    
    # Step Functions role
    stepfunctions_role_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Principal": {"Service": "states.amazonaws.com"},
                "Action": "sts:AssumeRole"
            }
        ]
    }
    
    try:
        sf_role = iam_client.create_role(
            RoleName='PharmacyStepFunctionsRole',
            AssumeRolePolicyDocument=json.dumps(stepfunctions_role_policy),
            Description='Execution role for Pharmacy Step Functions'
        )
        roles['stepfunctions_role'] = sf_role['Role']['Arn']
        
    except iam_client.exceptions.EntityAlreadyExistsException:
        role = iam_client.get_role(RoleName='PharmacyStepFunctionsRole')
        roles['stepfunctions_role'] = role['Role']['Arn']
    
    return roles

def deploy_lambda_functions(iam_roles: Dict[str, str]) -> Dict[str, str]:
    """Deploy all Lambda functions"""
    functions = {}
    
    lambda_configs = [
        {
            'name': 'pharmacy-entry-flow-lambda',
            'file': 'src/pharmacy_entry_flow_lambda.py',
            'handler': 'pharmacy_entry_flow_lambda.lambda_handler',
            'description': 'Handles Amazon Connect call flow logic'
        },
        {
            'name': 'abc-pharmacy-bot-lambda',
            'file': 'src/abc_pharmacy_bot.py',
            'handler': 'abc_pharmacy_bot.lambda_handler',
            'description': 'Amazon Lex bot for pharmacy services'
        },
        {
            'name': 'mcp-client-lambda',
            'file': 'src/mcp_client_lambda.py',
            'handler': 'mcp_client_lambda.lambda_handler',
            'description': 'MCP client for prescription validation'
        },
        {
            'name': 'prescription-email-notifier-lambda',
            'file': 'src/prescription_email_notifier_lambda.py',
            'handler': 'prescription_email_notifier_lambda.lambda_handler',
            'description': 'Sends email notifications for prescriptions'
        },
        {
            'name': 'mcp-server-validate-prescription-lambda',
            'file': 'src/mcp_server_validate_prescription_lambda.py',
            'handler': 'mcp_server_validate_prescription_lambda.lambda_handler',
            'description': 'MCP server for prescription validation'
        },
        {
            'name': 'prescription-processor-lambda',
            'file': 'src/prescription_processor_lambda.py',
            'handler': 'prescription_processor_lambda.lambda_handler',
            'description': 'Core prescription processing logic'
        }
    ]
    
    for config in lambda_configs:
        try:
            # Read function code
            with open(config['file'], 'r') as f:
                code = f.read()
            
            # Create deployment package
            import zipfile
            import io
            
            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, 'w') as zip_file:
                zip_file.writestr(f"{config['handler'].split('.')[0]}.py", code)
            
            zip_buffer.seek(0)
            
            # Deploy function
            response = lambda_client.create_function(
                FunctionName=config['name'],
                Runtime='python3.9',
                Role=iam_roles['lambda_role'],
                Handler=config['handler'],
                Code={'ZipFile': zip_buffer.read()},
                Description=config['description'],
                Timeout=30,
                MemorySize=256
            )
            
            functions[config['name']] = response['FunctionArn']
            logger.info(f"Deployed {config['name']}")
            
        except lambda_client.exceptions.ResourceConflictException:
            # Function already exists, update it
            response = lambda_client.get_function(FunctionName=config['name'])
            functions[config['name']] = response['Configuration']['FunctionArn']
            logger.info(f"Function {config['name']} already exists")
    
    return functions

def deploy_step_function(lambda_functions: Dict[str, str], iam_roles: Dict[str, str]) -> str:
    """Deploy Step Function workflow"""
    try:
        # Read Step Function definition
        with open('src/prescription_workflow.json', 'r') as f:
            definition = f.read()
        
        # Replace Lambda ARNs in definition
        for func_name, func_arn in lambda_functions.items():
            definition = definition.replace(
                f'arn:aws:states:::lambda:invoke',
                f'arn:aws:states:::lambda:invoke'
            )
        
        response = stepfunctions_client.create_state_machine(
            name='prescription-workflow',
            definition=definition,
            roleArn=iam_roles['stepfunctions_role'],
            type='STANDARD'
        )
        
        logger.info("Deployed Step Function: prescription-workflow")
        return response['stateMachineArn']
        
    except stepfunctions_client.exceptions.StateMachineAlreadyExists:
        # State machine already exists
        response = stepfunctions_client.list_state_machines()
        for sm in response['stateMachines']:
            if sm['name'] == 'prescription-workflow':
                return sm['stateMachineArn']

def deploy_lex_bot(lambda_functions: Dict[str, str]) -> Dict[str, str]:
    """Deploy Lex Bot"""
    # This is a simplified version - real implementation would be more complex
    logger.info("Lex Bot deployment would be implemented here")
    return {
        'bot_id': 'ABC_PHARMACY_BOT',
        'bot_alias': 'TSTALIASID'
    }

def configure_connect_flow(lambda_functions: Dict[str, str], lex_bot: Dict[str, str]) -> Dict[str, str]:
    """Configure Amazon Connect flow"""
    # This is a simplified version - real implementation would be more complex
    logger.info("Connect flow configuration would be implemented here")
    return {
        'flow_id': 'pharmacy-entry-flow',
        'contact_flow_arn': 'arn:aws:connect:us-east-1:123456789012:instance/12345678-1234-1234-1234-123456789012/contact-flow/87654321-4321-4321-4321-210987654321'
    }

def create_dynamodb_tables() -> Dict[str, str]:
    """Create DynamoDB tables"""
    dynamodb = boto3.resource('dynamodb')
    tables = {}
    
    table_configs = [
        {
            'name': 'prescriptions',
            'key_schema': [{'AttributeName': 'processing_id', 'KeyType': 'HASH'}],
            'attribute_definitions': [{'AttributeName': 'processing_id', 'AttributeType': 'S'}]
        },
        {
            'name': 'patients',
            'key_schema': [{'AttributeName': 'patient_id', 'KeyType': 'HASH'}],
            'attribute_definitions': [{'AttributeName': 'patient_id', 'AttributeType': 'S'}]
        },
        {
            'name': 'inventory',
            'key_schema': [{'AttributeName': 'medication_name', 'KeyType': 'HASH'}],
            'attribute_definitions': [{'AttributeName': 'medication_name', 'AttributeType': 'S'}]
        },
        {
            'name': 'medications',
            'key_schema': [{'AttributeName': 'medication_id', 'KeyType': 'HASH'}],
            'attribute_definitions': [{'AttributeName': 'medication_id', 'AttributeType': 'S'}]
        },
        {
            'name': 'doctors',
            'key_schema': [{'AttributeName': 'doctor_id', 'KeyType': 'HASH'}],
            'attribute_definitions': [{'AttributeName': 'doctor_id', 'AttributeType': 'S'}]
        }
    ]
    
    for config in table_configs:
        try:
            table = dynamodb.create_table(
                TableName=config['name'],
                KeySchema=config['key_schema'],
                AttributeDefinitions=config['attribute_definitions'],
                BillingMode='PAY_PER_REQUEST'
            )
            
            # Wait for table to be created
            table.wait_until_exists()
            tables[config['name']] = table.table_arn
            logger.info(f"Created DynamoDB table: {config['name']}")
            
        except Exception as e:
            if 'ResourceInUseException' in str(e):
                # Table already exists
                table = dynamodb.Table(config['name'])
                tables[config['name']] = table.table_arn
                logger.info(f"DynamoDB table {config['name']} already exists")
            else:
                logger.error(f"Error creating table {config['name']}: {str(e)}")
    
    return tables

def print_deployment_summary(resources: Dict[str, Any]):
    """Print deployment summary"""
    print("\n" + "="*60)
    print("PHARMACY MANAGEMENT SYSTEM DEPLOYMENT SUMMARY")
    print("="*60)
    
    print("\nLambda Functions:")
    for name, arn in resources['lambda_functions'].items():
        print(f"  • {name}: {arn}")
    
    print(f"\nStep Function:")
    print(f"  • prescription-workflow: {resources['step_function']}")
    
    print(f"\nLex Bot:")
    print(f"  • Bot ID: {resources['lex_bot']['bot_id']}")
    print(f"  • Bot Alias: {resources['lex_bot']['bot_alias']}")
    
    print(f"\nDynamoDB Tables:")
    for name, arn in resources['dynamodb_tables'].items():
        print(f"  • {name}: {arn}")
    
    print("\n" + "="*60)
    print("Deployment completed successfully!")
    print("="*60)

if __name__ == "__main__":
    main()