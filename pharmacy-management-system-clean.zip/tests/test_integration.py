"""
Integration Tests for ABC Pharmacy System
Tests the complete workflow from entry to notification
"""

import json
import boto3
import pytest
import uuid
from typing import Dict, Any

# Test configuration
TEST_CONFIG = {
    'prescription_number': 'RX123456',
    'patient_name': 'John Smith',
    'customer_input': 'I need to refill my prescription RX123456'
}

class TestABCPharmacyIntegration:
    """
    Integration tests for the complete pharmacy workflow
    """
    
    def setup_method(self):
        """Setup test environment"""
        self.lambda_client = boto3.client('lambda')
        self.stepfunctions_client = boto3.client('stepfunctions')
        self.request_id = str(uuid.uuid4())
    
    def test_pharmacy_entry_flow(self):
        """Test the pharmacy entry flow Lambda"""
        event = {
            'Details': {
                'Parameters': {
                    'customerInput': TEST_CONFIG['customer_input']
                },
                'ContactData': {
                    'ContactId': self.request_id
                }
            }
        }
        
        response = self.lambda_client.invoke(
            FunctionName='pharmacy-entry-flow-lambda',
            InvocationType='RequestResponse',
            Payload=json.dumps(event)
        )
        
        result = json.loads(response['Payload'].read())
        assert result['statusCode'] == 200
        assert 'message' in result['body']
        print(f"✅ Entry flow test passed: {result['body']['message']}")
    
    def test_mcp_server_validation(self):
        """Test MCP Server prescription validation"""
        event = {
            'method': 'validate_prescription',
            'params': {
                'prescription_number': TEST_CONFIG['prescription_number'],
                'patient_name': TEST_CONFIG['patient_name'],
                'request_id': self.request_id
            }
        }
        
        response = self.lambda_client.invoke(
            FunctionName='mcp-server-validate-prescription-lambda',
            InvocationType='RequestResponse',
            Payload=json.dumps(event)
        )
        
        result = json.loads(response['Payload'].read())
        assert result['statusCode'] == 200
        assert 'isValid' in result
        print(f"✅ MCP Server validation test passed: Valid={result['isValid']}")
    
    def test_mcp_client(self):
        """Test MCP Client Lambda"""
        event = {
            'action': 'validate',
            'prescriptionNumber': TEST_CONFIG['prescription_number'],
            'patientName': TEST_CONFIG['patient_name'],
            'requestId': self.request_id
        }
        
        response = self.lambda_client.invoke(
            FunctionName='mcp-client-lambda',
            InvocationType='RequestResponse',
            Payload=json.dumps(event)
        )
        
        result = json.loads(response['Payload'].read())
        assert result['statusCode'] == 200
        assert 'isValid' in result
        print(f"✅ MCP Client test passed: Valid={result['isValid']}")
    
    def test_prescription_processor(self):
        """Test prescription processor Lambda"""
        # First get validation data
        validation_data = {
            'isValid': True,
            'prescription_data': {
                'patient_name': TEST_CONFIG['patient_name'],
                'medication': 'Lisinopril 10mg',
                'prescriber': 'Dr. Johnson',
                'refills_remaining': 2
            }
        }
        
        event = {
            'prescriptionNumber': TEST_CONFIG['prescription_number'],
            'patientName': TEST_CONFIG['patient_name'],
            'validationData': validation_data,
            'requestId': self.request_id
        }
        
        response = self.lambda_client.invoke(
            FunctionName='prescription-processor-lambda',
            InvocationType='RequestResponse',
            Payload=json.dumps(event)
        )
        
        result = json.loads(response['Payload'].read())
        assert result['statusCode'] == 200
        assert result['status'] == 'SUCCESS'
        print(f"✅ Prescription processor test passed")
    
    def test_email_notifier(self):
        """Test email notification Lambda"""
        event = {
            'notificationType': 'SUCCESS',
            'prescriptionNumber': TEST_CONFIG['prescription_number'],
            'patientName': TEST_CONFIG['patient_name'],
            'requestId': self.request_id,
            'processingResult': {
                'processing_id': str(uuid.uuid4()),
                'status': 'ready_for_pickup',
                'medication': 'Lisinopril 10mg'
            }
        }
        
        response = self.lambda_client.invoke(
            FunctionName='prescription-email-notifier-lambda',
            InvocationType='RequestResponse',
            Payload=json.dumps(event)
        )
        
        result = json.loads(response['Payload'].read())
        assert result['statusCode'] == 200
        print(f"✅ Email notifier test passed")
    
    def test_complete_workflow(self):
        """Test the complete Step Function workflow"""
        input_data = {
            'prescriptionNumber': TEST_CONFIG['prescription_number'],
            'patientName': TEST_CONFIG['patient_name'],
            'requestId': self.request_id
        }
        
        # Start execution
        response = self.stepfunctions_client.start_execution(
            stateMachineArn='arn:aws:states:us-east-1:123456789012:stateMachine:prescription-workflow',
            name=f'test-execution-{self.request_id}',
            input=json.dumps(input_data)
        )
        
        execution_arn = response['executionArn']
        print(f"✅ Step Function execution started: {execution_arn}")
        
        # Note: In a real test, you would wait for completion and verify results
        # For this demo, we just verify the execution started successfully

def run_integration_tests():
    """Run all integration tests"""
    print("🧪 Starting ABC Pharmacy Integration Tests")
    print("="*50)
    
    test_suite = TestABCPharmacyIntegration()
    test_suite.setup_method()
    
    try:
        test_suite.test_mcp_server_validation()
        test_suite.test_mcp_client()
        test_suite.test_prescription_processor()
        test_suite.test_email_notifier()
        test_suite.test_pharmacy_entry_flow()
        # test_suite.test_complete_workflow()  # Uncomment when Step Function is deployed
        
        print("\n🎉 All integration tests passed!")
        
    except Exception as e:
        print(f"\n❌ Integration test failed: {str(e)}")
        raise

if __name__ == "__main__":
    run_integration_tests()