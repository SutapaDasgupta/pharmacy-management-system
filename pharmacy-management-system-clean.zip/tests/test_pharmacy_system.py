"""
Test suite for Pharmacy Management System
"""

import json
import pytest
from unittest.mock import Mock, patch, MagicMock
import sys
import os

# Add src directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Import modules to test
import pharmacy_entry_flow_lambda
import abc_pharmacy_bot
import mcp_client_lambda
import prescription_email_notifier_lambda
import mcp_server_validate_prescription_lambda
import prescription_processor_lambda

class TestPharmacyEntryFlow:
    """Test cases for Pharmacy Entry Flow Lambda"""
    
    def test_prescription_routing(self):
        """Test routing to prescription services"""
        event = {
            'Details': {
                'ContactData': {
                    'ContactId': 'test-contact-123',
                    'CustomerEndpoint': {'Address': '+15551234567'}
                },
                'Parameters': {
                    'CustomerInput': 'I need a prescription'
                }
            }
        }
        
        with patch('pharmacy_entry_flow_lambda.lex_client') as mock_lex:
            mock_lex.recognize_text.return_value = {
                'messages': [{'content': 'How can I help with your prescription?'}]
            }
            
            result = pharmacy_entry_flow_lambda.lambda_handler(event, None)
            
            assert result['statusCode'] == 200
            assert 'prescription' in result['body']['session_attributes']['service_type']

    def test_refill_routing(self):
        """Test routing to refill services"""
        event = {
            'Details': {
                'ContactData': {
                    'ContactId': 'test-contact-123',
                    'CustomerEndpoint': {'Address': '+15551234567'}
                },
                'Parameters': {
                    'CustomerInput': 'I need a refill'
                }
            }
        }
        
        result = pharmacy_entry_flow_lambda.lambda_handler(event, None)
        
        assert result['statusCode'] == 200
        assert result['body']['session_attributes']['service_type'] == 'refill'

class TestABCPharmacyBot:
    """Test cases for ABC Pharmacy Bot"""
    
    def test_new_prescription_intent(self):
        """Test new prescription intent handling"""
        event = {
            'sessionId': 'test-session-123',
            'sessionState': {
                'intent': {
                    'name': 'NewPrescription',
                    'slots': {
                        'PatientName': {'value': {'interpretedValue': 'John Doe'}},
                        'MedicationName': {'value': {'interpretedValue': 'Amoxicillin'}},
                        'DoctorName': {'value': {'interpretedValue': 'Dr. Smith'}},
                        'PrescriptionNumber': {'value': {'interpretedValue': 'RX123456'}}
                    }
                }
            },
            'sessionAttributes': {'customer_number': '+15551234567'}
        }
        
        with patch('abc_pharmacy_bot.stepfunctions_client') as mock_sf:
            mock_sf.start_execution.return_value = {
                'executionArn': 'arn:aws:states:us-east-1:123456789012:execution:test:12345678'
            }
            
            result = abc_pharmacy_bot.lambda_handler(event, None)
            
            assert 'Thank you!' in result['messages'][0]['content']
            assert 'Amoxicillin' in result['messages'][0]['content']

    def test_missing_slots(self):
        """Test handling of missing required slots"""
        event = {
            'sessionId': 'test-session-123',
            'sessionState': {
                'intent': {
                    'name': 'NewPrescription',
                    'slots': {
                        'PatientName': {'value': {'interpretedValue': 'John Doe'}},
                        'MedicationName': {},  # Missing medication
                        'DoctorName': {'value': {'interpretedValue': 'Dr. Smith'}},
                        'PrescriptionNumber': {'value': {'interpretedValue': 'RX123456'}}
                    }
                }
            }
        }
        
        result = abc_pharmacy_bot.lambda_handler(event, None)
        
        assert result['sessionState']['dialogAction']['type'] == 'ElicitSlot'
        assert result['sessionState']['dialogAction']['slotToElicit'] == 'MedicationName'

class TestMCPClient:
    """Test cases for MCP Client Lambda"""
    
    def test_validate_prescription_success(self):
        """Test successful prescription validation via MCP"""
        event = {
            'action': 'validate_prescription',
            'prescription_data': {
                'patient_name': 'John Doe',
                'medication_name': 'Amoxicillin',
                'doctor_name': 'Dr. Smith',
                'prescription_number': 'RX123456'
            }
        }
        
        with patch('mcp_client_lambda.lambda_client') as mock_lambda:
            mock_lambda.invoke.return_value = {
                'Payload': Mock(read=lambda: json.dumps({
                    'statusCode': 200,
                    'body': json.dumps({
                        'valid': True,
                        'details': {'medication': 'validated'},
                        'warnings': [],
                        'errors': []
                    })
                }).encode())
            }
            
            result = mcp_client_lambda.lambda_handler(event, None)
            
            assert result['statusCode'] == 200
            body = json.loads(result['body'])
            assert body['validation_passed'] is True

    def test_drug_interaction_check(self):
        """Test drug interaction checking"""
        event = {
            'action': 'check_drug_interactions',
            'prescription_data': {
                'medication_name': 'Warfarin',
                'current_medications': ['Aspirin'],
                'allergies': []
            }
        }
        
        with patch('mcp_client_lambda.lambda_client') as mock_lambda:
            mock_lambda.invoke.return_value = {
                'Payload': Mock(read=lambda: json.dumps({
                    'statusCode': 200,
                    'body': json.dumps({
                        'interactions_found': True,
                        'interactions': [{'medication1': 'Warfarin', 'medication2': 'Aspirin'}],
                        'severity_levels': ['moderate']
                    })
                }).encode())
            }
            
            result = mcp_client_lambda.lambda_handler(event, None)
            
            assert result['statusCode'] == 200
            body = json.loads(result['body'])
            assert body['interactions_found'] is True

class TestEmailNotifier:
    """Test cases for Email Notifier Lambda"""
    
    def test_success_notification(self):
        """Test sending success notification"""
        event = {
            'action': 'send_success_notification',
            'prescription_data': {
                'patient_name': 'John Doe',
                'medication_name': 'Amoxicillin',
                'prescription_number': 'RX123456',
                'email': 'john@example.com',
                'customer_phone': '+15551234567'
            },
            'processing_result': {
                'estimated_ready_time': '2 hours'
            }
        }
        
        with patch('prescription_email_notifier_lambda.ses_client') as mock_ses, \
             patch('prescription_email_notifier_lambda.sns_client') as mock_sns:
            
            mock_ses.send_email.return_value = {'MessageId': 'test-message-id'}
            mock_sns.publish.return_value = {'MessageId': 'test-sms-id'}
            
            result = prescription_email_notifier_lambda.lambda_handler(event, None)
            
            assert result['statusCode'] == 200
            body = json.loads(result['body'])
            assert body['email_sent'] is True
            assert body['sms_sent'] is True

    def test_error_notification(self):
        """Test sending error notification"""
        event = {
            'action': 'send_error_notification',
            'prescription_data': {
                'patient_name': 'John Doe',
                'prescription_number': 'RX123456',
                'email': 'john@example.com'
            },
            'error_type': 'validation',
            'error_details': {'message': 'Invalid prescription format'}
        }
        
        with patch('prescription_email_notifier_lambda.ses_client') as mock_ses:
            mock_ses.send_email.return_value = {'MessageId': 'test-message-id'}
            
            result = prescription_email_notifier_lambda.lambda_handler(event, None)
            
            assert result['statusCode'] == 200
            body = json.loads(result['body'])
            assert body['email_sent'] is True

class TestMCPServer:
    """Test cases for MCP Server Lambda"""
    
    def test_validate_prescription_valid(self):
        """Test prescription validation with valid data"""
        event = {
            'method': 'validate_prescription',
            'params': {
                'prescription': {
                    'patient_name': 'John Doe',
                    'medication_name': 'amoxicillin',
                    'doctor_name': 'Dr. Smith',
                    'prescription_number': 'RX123456AB'
                }
            }
        }
        
        result = mcp_server_validate_prescription_lambda.lambda_handler(event, None)
        
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert body['valid'] is True

    def test_validate_prescription_invalid(self):
        """Test prescription validation with invalid data"""
        event = {
            'method': 'validate_prescription',
            'params': {
                'prescription': {
                    'patient_name': '',  # Missing patient name
                    'medication_name': 'unknown_medication',
                    'doctor_name': 'Dr. Smith',
                    'prescription_number': 'INVALID'  # Invalid format
                }
            }
        }
        
        result = mcp_server_validate_prescription_lambda.lambda_handler(event, None)
        
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert body['valid'] is False
        assert len(body['errors']) > 0

    def test_drug_interactions(self):
        """Test drug interaction checking"""
        event = {
            'method': 'check_drug_interactions',
            'params': {
                'medication': 'warfarin',
                'patient_medications': ['aspirin'],
                'patient_allergies': []
            }
        }
        
        result = mcp_server_validate_prescription_lambda.lambda_handler(event, None)
        
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert body['interactions_found'] is True

class TestPrescriptionProcessor:
    """Test cases for Prescription Processor Lambda"""
    
    def test_validate_input_success(self):
        """Test successful input validation"""
        event = {
            'action': 'validate_input',
            'data': {
                'patient_name': 'john doe',
                'medication_name': 'AMOXICILLIN',
                'prescription_number': 'rx123456',
                'doctor_name': 'smith'
            }
        }
        
        result = prescription_processor_lambda.lambda_handler(event, None)
        
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert body['valid'] is True
        assert body['normalized_data']['patient_name'] == 'John Doe'
        assert body['normalized_data']['medication_name'] == 'amoxicillin'

    def test_validate_input_missing_fields(self):
        """Test input validation with missing fields"""
        event = {
            'action': 'validate_input',
            'data': {
                'patient_name': 'John Doe'
                # Missing required fields
            }
        }
        
        result = prescription_processor_lambda.lambda_handler(event, None)
        
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert body['valid'] is False
        assert len(body['errors']) > 0

    def test_process_prescription_success(self):
        """Test successful prescription processing"""
        event = {
            'action': 'process_prescription',
            'data': {
                'patient_name': 'John Doe',
                'medication_name': 'amoxicillin',
                'prescription_number': 'RX123456',
                'doctor_name': 'Dr. Smith',
                'quantity': 30
            }
        }
        
        result = prescription_processor_lambda.lambda_handler(event, None)
        
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert body['status'] == 'processed'
        assert 'pricing' in body

    def test_inventory_check(self):
        """Test inventory availability check"""
        event = {
            'action': 'check_inventory',
            'data': {
                'medication_name': 'amoxicillin',
                'quantity': 30
            }
        }
        
        result = prescription_processor_lambda.lambda_handler(event, None)
        
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert 'available' in body
        assert 'available_quantity' in body

if __name__ == '__main__':
    pytest.main([__file__])