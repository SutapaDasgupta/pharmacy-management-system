# Pharmacy Management System API Documentation

## Overview

This document describes the APIs and interfaces for the Pharmacy Management System components.

## Lambda Function APIs

### 1. Pharmacy Entry Flow Lambda

**Function Name**: `pharmacy-entry-flow-lambda`
**Handler**: `pharmacy_entry_flow_lambda.lambda_handler`

#### Input Event Structure (Amazon Connect)

```json
{
  "Details": {
    "ContactData": {
      "ContactId": "string",
      "CustomerEndpoint": {
        "Address": "string"
      }
    },
    "Parameters": {
      "CustomerInput": "string"
    }
  }
}
```

#### Response Structure

```json
{
  "statusCode": 200,
  "body": {
    "action": "transfer_to_lex|play_prompt",
    "message": "string",
    "bot_response": [],
    "session_attributes": {
      "customer_number": "string",
      "service_type": "prescription|refill|general|main_menu",
      "contact_id": "string",
      "intent": "string"
    },
    "transfer_to_agent": false
  }
}
```

### 2. ABC Pharmacy Bot Lambda

**Function Name**: `abc-pharmacy-bot-lambda`
**Handler**: `abc_pharmacy_bot.lambda_handler`

#### Input Event Structure (Amazon Lex)

```json
{
  "sessionId": "string",
  "sessionState": {
    "intent": {
      "name": "NewPrescription|RefillPrescription|CheckPrescriptionStatus|GeneralInquiry",
      "slots": {
        "PatientName": {
          "value": {
            "interpretedValue": "string"
          }
        },
        "MedicationName": {
          "value": {
            "interpretedValue": "string"
          }
        },
        "DoctorName": {
          "value": {
            "interpretedValue": "string"
          }
        },
        "PrescriptionNumber": {
          "value": {
            "interpretedValue": "string"
          }
        }
      }
    }
  },
  "sessionAttributes": {
    "customer_number": "string"
  }
}
```

#### Response Structure

```json
{
  "sessionState": {
    "dialogAction": {
      "type": "Close|ElicitSlot",
      "slotToElicit": "string"
    },
    "intent": {
      "name": "string",
      "state": "Fulfilled|Failed"
    }
  },
  "messages": [
    {
      "contentType": "PlainText",
      "content": "string"
    }
  ]
}
```

### 3. MCP Client Lambda

**Function Name**: `mcp-client-lambda`
**Handler**: `mcp_client_lambda.lambda_handler`

#### Input Event Structure

```json
{
  "action": "validate_prescription|check_drug_interactions|verify_insurance",
  "prescription_data": {
    "patient_name": "string",
    "medication_name": "string",
    "doctor_name": "string",
    "prescription_number": "string",
    "dosage": "string",
    "quantity": "number",
    "current_medications": ["string"],
    "allergies": ["string"],
    "insurance_info": {}
  }
}
```

#### Response Structure

##### Validate Prescription Response
```json
{
  "statusCode": 200,
  "body": {
    "validation_passed": true,
    "validation_details": {},
    "warnings": ["string"],
    "errors": ["string"]
  }
}
```

##### Drug Interactions Response
```json
{
  "statusCode": 200,
  "body": {
    "interactions_found": true,
    "interactions": [
      {
        "medication1": "string",
        "medication2": "string",
        "severity": "low|moderate|high",
        "description": "string"
      }
    ],
    "severity_levels": ["string"],
    "recommendations": ["string"]
  }
}
```

##### Insurance Verification Response
```json
{
  "statusCode": 200,
  "body": {
    "coverage_verified": true,
    "copay_amount": 10.00,
    "coverage_details": {},
    "prior_authorization_required": false
  }
}
```

### 4. MCP Server Validate Prescription Lambda

**Function Name**: `mcp-server-validate-prescription-lambda`
**Handler**: `mcp_server_validate_prescription_lambda.lambda_handler`

#### Input Event Structure (MCP Protocol)

```json
{
  "method": "validate_prescription|check_drug_interactions|verify_insurance|check_dosage|verify_doctor",
  "params": {
    "prescription": {
      "patient_name": "string",
      "medication_name": "string",
      "doctor_name": "string",
      "prescription_number": "string",
      "dosage": "string",
      "quantity": "number",
      "refills": "number"
    },
    "medication": "string",
    "patient_medications": ["string"],
    "patient_allergies": ["string"],
    "insurance_info": {},
    "patient_info": {},
    "doctor_name": "string"
  }
}
```

#### Response Structure

##### Validate Prescription Response
```json
{
  "statusCode": 200,
  "body": {
    "valid": true,
    "errors": ["string"],
    "warnings": ["string"],
    "details": {
      "medication": {
        "generic_name": "string",
        "brand_names": ["string"],
        "drug_class": "string",
        "controlled": false,
        "common_dosages": ["string"]
      },
      "doctor": {
        "full_name": "string",
        "license_number": "string",
        "specialties": ["string"],
        "verified": true
      },
      "dosage": {
        "amount": "number",
        "unit": "string",
        "parsed_dosage": "string"
      }
    }
  }
}
```

### 5. Prescription Processor Lambda

**Function Name**: `prescription-processor-lambda`
**Handler**: `prescription_processor_lambda.lambda_handler`

#### Input Event Structure

```json
{
  "action": "validate_input|process_prescription|check_inventory|update_status|calculate_pricing",
  "data": {
    "patient_name": "string",
    "medication_name": "string",
    "prescription_number": "string",
    "doctor_name": "string",
    "dosage": "string",
    "quantity": "number",
    "refills": "number",
    "customer_phone": "string",
    "session_id": "string",
    "processing_id": "string",
    "status": "string"
  }
}
```

#### Response Structure

##### Validate Input Response
```json
{
  "statusCode": 200,
  "body": {
    "valid": true,
    "errors": ["string"],
    "warnings": ["string"],
    "normalized_data": {
      "patient_name": "string",
      "medication_name": "string",
      "prescription_number": "string",
      "doctor_name": "string",
      "processing_id": "string",
      "created_at": "string",
      "status": "validated"
    }
  }
}
```

##### Process Prescription Response
```json
{
  "statusCode": 200,
  "body": {
    "processing_id": "string",
    "status": "processed|pending_inventory",
    "message": "string",
    "pricing": {
      "medication_cost": "number",
      "dispensing_fee": "number",
      "tax": "number",
      "total": "number",
      "quantity": "number",
      "unit_price": "number"
    },
    "estimated_ready_time": "string",
    "inventory_info": {},
    "fulfillment_scheduled": true
  }
}
```

##### Inventory Check Response
```json
{
  "statusCode": 200,
  "body": {
    "available": true,
    "available_quantity": "number",
    "quantity_needed": "number",
    "medication_name": "string"
  }
}
```

### 6. Prescription Email Notifier Lambda

**Function Name**: `prescription-email-notifier-lambda`
**Handler**: `prescription_email_notifier_lambda.lambda_handler`

#### Input Event Structure

```json
{
  "action": "send_success_notification|send_error_notification|send_status_update|send_ready_notification",
  "prescription_data": {
    "patient_name": "string",
    "medication_name": "string",
    "prescription_number": "string",
    "email": "string",
    "customer_phone": "string"
  },
  "processing_result": {
    "estimated_ready_time": "string"
  },
  "error_type": "validation|mcp_error|mcp_validation_failed|processing",
  "error_details": {}
}
```

#### Response Structure

```json
{
  "statusCode": 200,
  "body": {
    "message": "string",
    "email_sent": true,
    "sms_sent": true
  }
}
```

## Step Functions Workflow

### Prescription Workflow State Machine

**State Machine Name**: `prescription-workflow`
**Definition File**: `src/prescription_workflow.json`

#### Input Structure

```json
{
  "patient_name": "string",
  "medication_name": "string",
  "doctor_name": "string",
  "prescription_number": "string",
  "customer_phone": "string",
  "session_id": "string"
}
```

#### Workflow States

1. **ValidateInput**: Validates prescription input data
2. **CheckValidation**: Decision state based on validation result
3. **CallMCPClient**: Calls MCP client for prescription validation
4. **CheckMCPValidation**: Decision state based on MCP validation
5. **ProcessPrescription**: Core prescription processing
6. **SendNotification**: Sends success notification
7. **Success**: Final success state
8. **ValidationError**: Handles validation errors
9. **MCPError**: Handles MCP service errors
10. **MCPValidationFailed**: Handles MCP validation failures
11. **ProcessingError**: Handles processing errors
12. **NotificationError**: Handles notification errors
13. **Failure**: Final failure state

#### Output Structure

```json
{
  "status": "success|failure|partial_success",
  "message": "string",
  "processing_id": "string",
  "error_details": {}
}
```

## DynamoDB Table Schemas

### Prescriptions Table

**Table Name**: `prescriptions`
**Primary Key**: `processing_id` (String)

```json
{
  "processing_id": "string",
  "patient_name": "string",
  "medication_name": "string",
  "prescription_number": "string",
  "doctor_name": "string",
  "dosage": "string",
  "quantity": "number",
  "refills": "number",
  "status": "string",
  "customer_phone": "string",
  "session_id": "string",
  "pricing": {
    "medication_cost": "number",
    "dispensing_fee": "number",
    "tax": "number",
    "total": "number"
  },
  "created_at": "string",
  "updated_at": "string"
}
```

### Patients Table

**Table Name**: `patients`
**Primary Key**: `patient_id` (String)

```json
{
  "patient_id": "string",
  "patient_name": "string",
  "email": "string",
  "phone": "string",
  "address": {
    "street": "string",
    "city": "string",
    "state": "string",
    "zip": "string"
  },
  "insurance_info": {},
  "allergies": ["string"],
  "current_medications": ["string"],
  "created_at": "string",
  "updated_at": "string"
}
```

### Inventory Table

**Table Name**: `inventory`
**Primary Key**: `medication_name` (String)

```json
{
  "medication_name": "string",
  "available_quantity": "number",
  "reserved_quantity": "number",
  "unit_price": "number",
  "location": "string",
  "expiration_dates": ["string"],
  "last_updated": "string"
}
```

### Medications Table

**Table Name**: `medications`
**Primary Key**: `medication_id` (String)

```json
{
  "medication_id": "string",
  "generic_name": "string",
  "brand_names": ["string"],
  "drug_class": "string",
  "controlled": "boolean",
  "schedule": "string",
  "common_dosages": ["string"],
  "interactions": ["string"],
  "side_effects": ["string"],
  "created_at": "string",
  "updated_at": "string"
}
```

### Doctors Table

**Table Name**: `doctors`
**Primary Key**: `doctor_id` (String)

```json
{
  "doctor_id": "string",
  "full_name": "string",
  "license_number": "string",
  "specialties": ["string"],
  "verified": "boolean",
  "contact_info": {
    "phone": "string",
    "email": "string",
    "address": {}
  },
  "created_at": "string",
  "updated_at": "string"
}
```

## Error Codes and Messages

### Common Error Codes

| Code | Description | Resolution |
|------|-------------|------------|
| 400 | Bad Request | Check input parameters |
| 401 | Unauthorized | Verify authentication |
| 403 | Forbidden | Check permissions |
| 404 | Not Found | Verify resource exists |
| 429 | Too Many Requests | Implement rate limiting |
| 500 | Internal Server Error | Check logs and retry |
| 502 | Bad Gateway | Check downstream services |
| 503 | Service Unavailable | Retry with backoff |

### Business Logic Error Codes

| Code | Description | Context |
|------|-------------|---------|
| INVALID_PRESCRIPTION | Invalid prescription format | Prescription validation |
| MEDICATION_NOT_FOUND | Unknown medication | Medication lookup |
| DOCTOR_NOT_VERIFIED | Doctor not in verified database | Doctor validation |
| INSUFFICIENT_INVENTORY | Not enough medication in stock | Inventory check |
| DRUG_INTERACTION | Potential drug interaction found | Safety check |
| INSURANCE_NOT_COVERED | Medication not covered by insurance | Insurance verification |

## Rate Limits

### Lambda Function Limits

- **Concurrent Executions**: 1000 (default account limit)
- **Request Rate**: No specific limit (governed by concurrent executions)
- **Payload Size**: 6MB (synchronous), 256KB (asynchronous)

### DynamoDB Limits

- **Read/Write Capacity**: On-demand (auto-scaling)
- **Item Size**: 400KB maximum
- **Query/Scan**: 1MB result set limit

### External Service Limits

- **SES**: 200 emails per day (sandbox), higher with production access
- **SNS**: 100 SMS per day (default), higher with limit increase
- **Step Functions**: 25,000 state transitions per execution

## Authentication and Authorization

### IAM Roles

#### Lambda Execution Role
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:PutItem",
        "dynamodb:UpdateItem",
        "dynamodb:Query",
        "dynamodb:Scan"
      ],
      "Resource": "arn:aws:dynamodb:*:*:table/pharmacy-*"
    }
  ]
}
```

#### Step Functions Execution Role
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "lambda:InvokeFunction"
      ],
      "Resource": "arn:aws:lambda:*:*:function:*-lambda"
    }
  ]
}
```

## Monitoring and Logging

### CloudWatch Metrics

- **Lambda**: Duration, Errors, Invocations, Throttles
- **Step Functions**: ExecutionsStarted, ExecutionsSucceeded, ExecutionsFailed
- **DynamoDB**: ConsumedReadCapacityUnits, ConsumedWriteCapacityUnits

### Custom Metrics

- **Prescription Processing Time**: Average time to process prescriptions
- **Validation Success Rate**: Percentage of successful validations
- **Notification Delivery Rate**: Percentage of successful notifications

### Log Formats

#### Lambda Function Logs
```json
{
  "timestamp": "2024-01-01T12:00:00.000Z",
  "level": "INFO",
  "message": "Processing prescription",
  "prescription_id": "string",
  "patient_name": "string",
  "medication": "string"
}
```

#### Error Logs
```json
{
  "timestamp": "2024-01-01T12:00:00.000Z",
  "level": "ERROR",
  "message": "Prescription validation failed",
  "error": "string",
  "prescription_id": "string",
  "stack_trace": "string"
}
```